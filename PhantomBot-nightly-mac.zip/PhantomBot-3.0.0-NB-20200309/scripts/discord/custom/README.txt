Place custom scripts in this directory.

More information regarding this may be found at the following URL:

https://community.phantombot.tv/t/modifying-a-stock-phantombot-module/411
