$.lang.register('highlightcommand.highlight.offline', 'Highlights can only be set when the stream is online.');
$.lang.register('highlightcommand.highlight.usage', 'Usage: !highlight [description] (Using date stamp for timezone: $1)');
$.lang.register('highlightcommand.highlight.success', 'Highlight successfully saved with a timestamp of $1.');
$.lang.register('highlightcommand.gethighlights.no-highlights', 'There are currently no highlights.');
$.lang.register('highlightcommand.clearhighlights.success', 'Highlights have been cleared.');
$.lang.register('highlightcommand.highlights', 'Highlights: $1');