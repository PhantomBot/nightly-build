$.lang.register('discord.tipeeestreamhandler.usage', 'Usage: !tipeeestreamhandler [toggle / message / channel]');
$.lang.register('discord.tipeeestreamhandler.toggle', 'TipeeeStream donation announcements have been $1.');
$.lang.register('discord.tipeeestreamhandler.message.usage', 'Usage: !tipeeestreamhandler message [message] - Tags: (name) (amount) (currency) (formattedamount) (message)');
$.lang.register('discord.tipeeestreamhandler.message.set', 'TipeeeStream donation message set to: $1');
$.lang.register('discord.tipeeestreamhandler.channel.usage', 'Usage: !tipeeestreamhandler channel [channel name]');
$.lang.register('discord.tipeeestreamhandler.channel.set', 'TipeeeStream donation announcements will now be made in channel #$1');
