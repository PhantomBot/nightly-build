$.lang.register('gamescanhandler.gamescan.usage', 'Usage: !gamescan [game name]');
$.lang.register('gamescanhandler.gamescan.notplayed', '$1 has not played $2 yet!');
$.lang.register('gamescanhandler.gamescan.hasplayeddates', '$1 has played $2 on: $3, (AntiSpam +$4 dates found.)');
$.lang.register('gamescanhandler.gamescan.hasplayed', '$1 has played $2 on: $3.');