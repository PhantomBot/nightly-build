$.lang.register('raidsystem.raid', 'We are raiding http://twitch.tv/$1 ! $2');
$.lang.register('raidsystem.raid.usage', 'Usage: !raid [username]');
$.lang.register('raidsystem.raided', 'We are being raided by $1! This is the $2 time $1 has raided. Go check out their channel and hit that follow button at http://twitch.tv/$1 !');
$.lang.register('raidsystem.raider.usage', 'Usage: !raider [username] -- !raider count [username]');
$.lang.register('raidsystem.message.nomessageset', '$1 hasn\'t set a raid message yet! Use "!setraidmsg [message...]" to set one.');
$.lang.register('raidsystem.message.usage', 'Usage "!setraidmsg [message...]" to set one.');
$.lang.register('raidsystem.message.setsuccess', 'The new raid message is "$1".');
$.lang.register('raidsystem.console.announceraidmsg', 'The current raid message is "$1".');