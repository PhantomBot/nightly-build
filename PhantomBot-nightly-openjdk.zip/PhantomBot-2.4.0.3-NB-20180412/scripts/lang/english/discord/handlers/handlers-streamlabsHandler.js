$.lang.register('discord.streamlabshandler.usage', 'Usage: !streamlabshandler [toggle / message / channel]');
$.lang.register('discord.streamlabshandler.toggle', 'StreamLabs donation announcements have been $1.');
$.lang.register('discord.streamlabshandler.message.usage', 'Usage: !streamlabshandler message [message] - Tags: (name) (amount) (currency) (message)');
$.lang.register('discord.streamlabshandler.message.set', 'StreamLabs donation message set to: $1');
$.lang.register('discord.streamlabshandler.channel.usage', 'Usage: !streamlabshandler channel [channel name]');
$.lang.register('discord.streamlabshandler.channel.set', 'StreamLabs donation annoucements will now be made in channel #$1');