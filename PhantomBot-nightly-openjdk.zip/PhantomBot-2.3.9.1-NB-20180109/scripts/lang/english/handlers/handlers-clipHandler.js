$.lang.register('cliphandler.toggle.off', 'Clips announcements have been disabled.');
$.lang.register('cliphandler.toggle.on', 'Clips announcements have been enabled.');
$.lang.register('cliphandler.message.usage', 'Usage: !clipsmessage (message) - Tags: (name), (url)');
$.lang.register('cliphandler.message.set', 'Clips message has been set to: $1.');
$.lang.register('cliphandler.channel.usage', 'Usage: !clipschannel (channel).  Currently: $1');
$.lang.register('cliphandler.channel.set', 'Clips channel has been set to: $1.');
$.lang.register('cliphandler.noclip', 'No clip found');
$.lang.register('cliphandler.lastclip', 'Last Clip: $1');
$.lang.register('cliphandler.topclip', 'Today\'s Most Viewed Clip: $1');
