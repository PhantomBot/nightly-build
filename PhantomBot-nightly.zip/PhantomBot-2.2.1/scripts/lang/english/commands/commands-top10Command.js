$.lang.register('top5.default', 'Top $1 $2: $3');
$.lang.register('top5.points-disabled', 'Points are disabled.');
$.lang.register('top5.amount.points.usage', 'usage: !topamount (amount) - Set how many people who up in the !top points list.');
$.lang.register('top5.amount.max', 'the max amount is 15 users.');
$.lang.register('top5.amount.points.set', '$1 users will now how in the !top command.');
$.lang.register('top5.amount.time.usage', 'usage: !toptimeamount (amount) - Set how many people who up in the !toptime list.');
$.lang.register('top5.amount.time.set', '$1 users will now how in the !toptime command.');
