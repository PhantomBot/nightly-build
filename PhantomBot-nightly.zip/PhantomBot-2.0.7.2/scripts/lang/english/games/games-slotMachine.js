$.lang.register('slotmachine.result.start', '$1: [ $2 $3 $4 ] ');
$.lang.register('slotmachine.result.win', ' +$1 ');