$.lang.register("top5.default","Top 5 $1: $2"),$.lang.register("top5.points-disabled","Points are disabled.");
