$.lang.register('keywordhandler.add.usage', 'Usage: !keyword add (keyword) (response)');
$.lang.register('keywordhandler.keyword.404', 'That keyword does not exist.');
$.lang.register('keywordhandler.keyword.added', 'keyword "$1" added!');
$.lang.register('keywordhandler.keyword.removed', 'keyword "$1" has been removed!');
$.lang.register('keywordhandler.keyword.usage', 'Usage: !keyword [add / remove] [keyword]');
$.lang.register('keywordhandler.remove.usage', 'Usage: !keyword remove [keyword]');
