$.lang.register('discord.pointsystem.self.points', 'You currently have $1.'); // Use $2 to display the users time and $3 for the user's rank. The rank also has his name by default.
$.lang.register('discord.pointsystem.other.points', '$1 currently has $2.'); // Use $3 to display the users time and $4 for the user's rank. The rank also has his name by default.
$.lang.register('discord.pointsystem.no.points.other', 'That user currently has no $1.');
