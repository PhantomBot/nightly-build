$.lang.register('discord.twitterhandler.tweet', '[Twitter Feed From]');
$.lang.register('discord.twitterhandler.usage', 'Usage: !twitterhandler [toggle / channel]');
$.lang.register('discord.twitterhandler.toggle', 'Twitter annoucements have been $1.');
$.lang.register('discord.twitterhandler.channel.usage', 'Usage: !twitterhandler channel [channel name]');
$.lang.register('discord.twitterhandler.channel.set', 'Twitter annoucements will now be made in channel #$1');
