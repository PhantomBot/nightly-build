$.lang.register('discord.streamelementshandler.usage', 'Usage: !streamelementshandler [toggle / message / channel]');
$.lang.register('discord.streamelementshandler.toggle', 'StreamElements donation announcements have been $1.');
$.lang.register('discord.streamelementshandler.message.usage', 'Usage: !streamelementshandler message [message] - Tags: (name) (amount) (currency) (message)');
$.lang.register('discord.streamelementshandler.message.set', 'StreamElements donation message set to: $1');
$.lang.register('discord.streamelementshandler.channel.usage', 'Usage: !streamelementshandler channel [channel name]');
$.lang.register('discord.streamelementshandler.channel.set', 'StreamElements donation annoucements will now be made in channel #$1');
$.lang.register('discord.streamelementshandler.embed.title', 'New Tip!');