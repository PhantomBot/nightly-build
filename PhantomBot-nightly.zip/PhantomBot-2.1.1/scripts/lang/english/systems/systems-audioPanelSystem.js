$.lang.register('audiohook.usage', 'usage: !audiohook [play | list]');
$.lang.register('audiohook.play.usage', 'usage: !audiohook play [audio_hook]');
$.lang.register('audiohook.play.404', 'Audiohook does not exist: $1');
$.lang.register('audiohook.play.success', 'Sent audio hook: $1');
$.lang.register('audiohook.list', 'Audio Hooks: $1');
$.lang.register('audiohook.list.total', 'Total Pages: $1');
