$.lang.register('roll.rolled', '$1 rolls a [$2] and [$3]. ');
$.lang.register('roll.doubleone', 'Snake eyes for $1! ');
$.lang.register('roll.doubletwo', 'Hard four for $1! ');
$.lang.register('roll.doublethree', 'Hard six for $1! ');
$.lang.register('roll.doublefour', 'Hard eight for $1! ');
$.lang.register('roll.doublefive', 'Hard ten for $1! ');
$.lang.register('roll.doublesix', 'Boxcars to the max!!! $1! ');
$.lang.register('roll.rewards.usage', 'usage: !roll rewards [double 1\'s] [2\'s] [3\'s] [4\'s] [5\'s] [6\'s]. Currently: $1');
$.lang.register('roll.rewards.success', 'Updated rewards for the dice roll.');
