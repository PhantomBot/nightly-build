$.lang.register('discord.commandcooldown.cooldown.usage', 'Usage: !cooldown [toggleglobal / globaltime]');
$.lang.register('discord.commandcooldown.cooldown.toggle.global', 'The global cooldown has been $1.');
$.lang.register('discord.commandcooldown.cooldown.global.time.usage', 'Usage: !cooldown globaltime [seconds]');
$.lang.register('discord.commandcooldown.cooldown.global.time.set', 'The global cooldown time has been set to $1 seconds.');
