$.lang.register('cleanupsystem.run.progress', 'Running cleanup.... $1%');
$.lang.register('cleanupsystem.run.success', 'Cleanup finished! Check the log files for more info.');
$.lang.register('cleanupsystem.run.error', 'Could not run cleanup!');