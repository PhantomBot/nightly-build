$.lang.register('dataservicehandler.status.success', 'Data has been sent and loaded.');
$.lang.register('dataservicehandler.status.authentication_failed', 'Data has been sent and loaded.');
$.lang.register('dataservicehandler.status.no_such_user', 'No such user defined in remote service.');
$.lang.register('dataservicehandler.status.no_auth_key', 'No authorization key has been configured.');
$.lang.register('dataservicehandler.status.launch_fail', 'Failed to launch the remote API.');
