$.lang.register('discord.streamonline', '$1 just went online on Twitch at https://www.twitch.tv/$1');
