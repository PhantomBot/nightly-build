$.lang.register('discord.misc.module.usage', 'Usage: !module [enable / disable / list]');
$.lang.register('discord.misc.module.enabled', 'Module: $1 has been enabled.');
$.lang.register('discord.misc.module.disabled', 'Module: $1 has been disabled.');
$.lang.register('discord.misc.module.list', 'Discord Module list: \r\n $1');
$.lang.register('discord.misc.module.404', 'That module does not exist: $1');
