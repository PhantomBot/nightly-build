$.lang.register('discord.streamtiphandler.usage', 'Usage: !streamtiphandler [toggle / message / channel]');
$.lang.register('discord.streamtiphandler.toggle', 'StreamTip donation announcements have been $1.');
$.lang.register('discord.streamtiphandler.message.usage', 'Usage: !streamtiphandler message [message] - Tags: (name) (amount) (currency) (message)');
$.lang.register('discord.streamtiphandler.message.set', 'StreamTip donation message set to: $1');
$.lang.register('discord.streamtiphandler.channel.usage', 'Usage: !streamtiphandler channel [channel name]');
$.lang.register('discord.streamtiphandler.channel.set', 'StreamTip donation announcements will now be made in channel #$1');
$.lang.register('discord.streamtiphandler.embed.title', 'New Tip!');