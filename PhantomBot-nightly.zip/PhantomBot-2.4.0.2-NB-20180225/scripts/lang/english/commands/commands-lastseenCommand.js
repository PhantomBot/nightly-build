$.lang.register('lastseen.404', 'I haven\'t seen $1 yet.');
$.lang.register('lastseen.response', '$1 has last been seen on $2 @ $3');
$.lang.register('lastseen.usage', 'Usage: !lastseen [username].');