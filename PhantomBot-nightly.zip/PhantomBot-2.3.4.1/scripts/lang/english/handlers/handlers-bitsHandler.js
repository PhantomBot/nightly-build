$.lang.register('bitshandler.toggle.off', 'Bits announcements have been disabled.');
$.lang.register('bitshandler.toggle.on', 'Bits announcements have been enabled.');
$.lang.register('bitshandler.message.usage', 'Usage: !bitsmessage (message) - Tags: (name), (amount), (reward)');
$.lang.register('bitshandler.message.set', 'Bits message has been set to: $1.');
$.lang.register('bitshandler.reward.usage', 'Usage: !bitsreward (amount)');
$.lang.register('bitshandler.reward.set', 'Bits reward has been set to: $1.');
$.lang.register('bitshandler.minimum.usage', 'Usage: !bitsminimum (amount)');
$.lang.register('bitshandler.minimum.set', 'Bits minimum has been set to $1 bits.');
