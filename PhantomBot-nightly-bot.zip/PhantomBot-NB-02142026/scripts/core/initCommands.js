/*
 * Copyright (C) 2016-2026 phantombot.github.io/PhantomBot
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/* global Packages */

(function() {
    let useBotName = $.getSetIniDbBoolean('settings', 'initCommands.useBotName', true);
    let sentReady = false;

    /*
     * @event command
     */
    $.bind('command', function(event) {
        let sender = event.getSender(),
            command = event.getCommand(),
            argsString = event.getArguments(),
            args = event.getArgs(),
            action = args[0],
            subAction = args[1];

        if ($.equalsIgnoreCase(command, 'pbcore')) {
            if (action === undefined) {
                $.say($.whisperPrefix(sender) + $.lang.get('init.usage', command));
                return;
            }

            /*
             * @commandpath pbcore usebotname - Toggles using the bot name for initCommands commands.
             */
            if ($.equalsIgnoreCase(action, 'usebotname')) {
                useBotName = !useBotName;
                $.setIniDbBoolean('settings', 'initCommands.useBotName', useBotName);

                if (useBotName) {
                    $.registerChatAlias($.botName.toLowerCase(), 'pbcore', './core/initCommands.js');
                } else {
                    $.unregisterChatAlias($.botName.toLowerCase());
                }

                $.say($.whisperPrefix(sender) + $.lang.get('init.toggle.botname', $.botName.toLowerCase(), (useBotName ? $.lang.get('common.enabled') : $.lang.get('common.disabled'))));
            }

            /*
             * @commandpath pbcore disconnect - Removes the bot from your channel.
             */
            if ($.equalsIgnoreCase(action, 'disconnect')) {
                $.say($.whisperPrefix(sender) + $.lang.get('init.disconnect'));

                setTimeout(function() {
                    Packages.java.lang.System.exit(0);
                }, 1000);
            }

            /*
             * @commandpath pbcore reconnect - Reconnects the bot to TMI and EventSub.
             */
            if ($.equalsIgnoreCase(action, 'reconnect')) {
                $.say($.whisperPrefix(sender) + $.lang.get('init.reconnect'));

                setTimeout(function() {
                    Packages.tv.phantombot.PhantomBot.instance().reconnect();
                }, 1000);
            }

            /*
             * @commandpath pbcore moderate - Forces the bot to detect its moderator status.
             */
            if ($.equalsIgnoreCase(action, 'moderate')) {
                Packages.tv.phantombot.PhantomBot.instance().getSession().getModerationStatus();
            }

            /*
             * @commandpath pbcore forceonline - Forces the bot to mark the channel as online.
             */
            if ($.equalsIgnoreCase(action, 'forceonline')) {
                $.say($.whisperPrefix(sender) + $.lang.get('init.forceonline'));

                Packages.tv.phantombot.event.EventBus.instance().postAsync(new Packages.tv.phantombot.event.twitch.online.TwitchOnlineEvent());
            }

            /*
             * @commandpath pbcore forceoffline - Forces the bot to mark the channel as offline.
             */
            if ($.equalsIgnoreCase(action, 'forceoffline')) {
                $.say($.whisperPrefix(sender) + $.lang.get('init.forceoffline'));

                Packages.tv.phantombot.event.EventBus.instance().postAsync(new Packages.tv.phantombot.event.twitch.offline.TwitchOfflineEvent());
            }

            /*
             * @commandpath pbcore setconnectmessage [message] - Sets a message that will be said once the bot joins the channel.
             */
            if ($.equalsIgnoreCase(action, 'setconnectmessage')) {
                if (subAction === undefined) {
                    $.say($.whisperPrefix(sender) + $.lang.get('init.connected.msg.usage', bot));
                    return;
                }

                let message = args.slice(1).join(' ');

                $.setIniDbString('settings', 'connectedMsg', message);
                $.say($.whisperPrefix(sender) + $.lang.get('init.connected.msg', message));
            }

            /*
             * @commandpath pbcore removeconnectmessage - Removes the message said when the bot joins the channel.
             */
            if ($.equalsIgnoreCase(action, 'removeconnectmessage')) {
                $.inidb.del('settings', 'connectedMsg');
                $.say($.whisperPrefix(sender) + $.lang.get('init.connected.msg.removed'));
            }

            /*
             * @commandpath pbcore togglepricecommods - Toggles if moderators and higher pay for commands.
             */
            if ($.equalsIgnoreCase(action, 'togglepricecommods')) {
                let toggle = !$.getIniDbBoolean('settings', 'pricecomMods', false);

                $.setIniDbBoolean('settings', 'pricecomMods', toggle);
                $.say($.whisperPrefix(sender) + (toggle ? $.lang.get('init.mod.toggle.on.pay') : $.lang.get('init.mod.toggle.off.pay')));
            }

            /*
             * @commandpath pbcore togglepermcommessage - Toggles if the no permission message is said in the chat.
             */
            if ($.equalsIgnoreCase(action, 'togglepermcommessage')) {
                let toggle = !$.getIniDbBoolean('settings', 'permComMsgEnabled', false);

                $.setIniDbBoolean('settings', 'permComMsgEnabled', toggle);
                $.say($.whisperPrefix(sender) + (toggle ? $.lang.get('init.mod.toggle.perm.msg.on') : $.lang.get('init.mod.toggle.perm.msg.off')));
            }

            /*
             * @commandpath pbcore togglepricecommessage - Toggles if the cost message is said in the chat.
             */
            if ($.equalsIgnoreCase(action, 'togglepricecommessage')) {
                let toggle = !$.getIniDbBoolean('settings', 'priceComMsgEnabled', false);

                $.setIniDbBoolean('settings', 'priceComMsgEnabled', toggle);
                $.say($.whisperPrefix(sender) + (toggle ? $.lang.get('init.mod.toggle.price.msg.on') : $.lang.get('init.mod.toggle.price.msg.off')));
            }

            /*
             * @commandpath pbcore togglecooldownmessage - Toggles if the cooldown message is said in the chat.
             */
            if ($.equalsIgnoreCase(action, 'togglecooldownmessage')) {
                let toggle = !$.getIniDbBoolean('settings', 'coolDownMsgEnabled', false);

                $.setIniDbBoolean('settings', 'coolDownMsgEnabled', toggle);
                $.say($.whisperPrefix(sender) + (toggle ? $.lang.get('init.toggle.cooldown.msg.on') : $.lang.get('init.toggle.cooldown.msg.off')));
            }

            /*
             * @commandpath pbcore togglecustomcommandat - Toggles if custom commands without command tags can be targeted by mods using !mycommand @user
             */
            if ($.equalsIgnoreCase(action, 'togglecustomcommandat')) {
                let toggle = !$.getIniDbBoolean('settings', 'customCommandAtEnabled', true);

                $.setIniDbBoolean('settings', 'customCommandAtEnabled', toggle);
                $.say($.whisperPrefix(sender) + (toggle ? $.lang.get('init.toggle.customCommandAt.on') : $.lang.get('init.toggle.customCommandAt.off')));
            }
        }

        if ($.equalsIgnoreCase(command, 'module')) {
            if (action === undefined) {
                $.say($.whisperPrefix(sender) + $.lang.get('init.module.usage'));
                return;
            }

            /*
             * @commandpath module reload [path/all (option)] - Force reloads all active modules or force reloads a single module.
             */
            if ($.equalsIgnoreCase(action, 'reload')) {
                if (subAction === undefined || $.equalsIgnoreCase(subAction, 'all')) {
                    $.bot.loadScriptRecursive('', false, true);
                    $.say($.whisperPrefix(sender) + $.lang.get('init.module.reload.all'));
                    return;
                }
                if ($.getIniDbString('modules', subAction, undefined) !== undefined){
                    let module = $.bot.getModule(subAction);
                    if (module !== undefined) {
                        $.bot.loadScript(module.scriptName, true, false);
                        $.say($.whisperPrefix(sender) + $.lang.get('init.module.reload', subAction));
                    } else {
                        $.say($.whisperPrefix(sender) + $.lang.get('init.module.delete.404'));
                    }
                    return;
                }

                $.say($.whisperPrefix(sender) + $.lang.get('init.module.reload.usage'));
                return;
            }

            /*
             * @commandpath module delete [path] - Removes a module from the modules list. This does not remove the module itself.
             */
            if ($.equalsIgnoreCase(action, 'delete')) {
                if (subAction === undefined) {
                    $.say($.whisperPrefix(sender) + $.lang.get('init.module.delete.usage'));
                    return;
                } else if ($.getIniDbString('modules', subAction, undefined) === undefined) {
                    $.say($.whisperPrefix(sender) + $.lang.get('init.module.delete.404', subAction));
                    return;
                }

                $.inidb.del('modules', subAction);
                $.say($.whisperPrefix(sender) + $.lang.get('init.module.delete.success', subAction));
            }

            /*
             * @commandpath module list - Gives a list of all the modules with their current status.
             */
            if ($.equalsIgnoreCase(action, 'list')) {
                let keys = Object.keys($.bot.modules),
                    modules = $.bot.modules,
                    temp = [],
                    i;

                for (i in keys) {
                    if (modules[keys[i]].scriptName.indexOf('./core') !== -1 || modules[keys[i]].scriptName.indexOf('./lang') !== -1) {
                        continue;
                    }

                    temp.push(modules[keys[i]].scriptName + (modules[keys[i]].isEnabled ? ' (' + $.lang.get('common.enabled') + ')' : ' (' + $.lang.get('common.disabled') + ')'));
                }

                let totalPages = $.paginateArray(temp, 'init.module.list', ', ', true, sender, (isNaN(parseInt(subAction)) ? 1 : parseInt(subAction)));

                if (totalPages > 0) {
                    $.say($.whisperPrefix(sender) + $.lang.get('init.module.list.total', totalPages));
                }
            }

            /*
             * @commandpath module status [module path] - Retrieve the current status (enabled/disabled) of the given module
             */
            if ($.equalsIgnoreCase(action, 'status')) {
                if (subAction === undefined) {
                    $.say($.whisperPrefix(sender) + $.lang.get('init.module.usage.status'));
                    return;
                }

                let module = $.bot.getModule(subAction);

                if (module !== undefined) {
                    if (module.isEnabled) {
                        $.say($.whisperPrefix(sender) + $.lang.get('init.module.check.enabled', module.getModuleName()));
                    } else {
                        $.say($.whisperPrefix(sender) + $.lang.get('init.module.check.disabled', module.getModuleName()));
                    }
                } else {
                    $.say($.whisperPrefix(sender) + $.lang.get('init.module.404'));
                }
            }

            /*
             * @commandpath module enable [module path] - Enable a module using the path and name of the module
             */
            if ($.equalsIgnoreCase(action, 'enable')) {
                if (subAction === undefined) {
                    $.say($.whisperPrefix(sender) + $.lang.get('init.module.usage.enable'));
                    return;
                }

                if (subAction.indexOf('./core') !== -1 || subAction.indexOf('./lang') !== -1) {
                    return;
                }

                let module = $.bot.getModule(subAction);

                if (module !== undefined) {
                    $.setIniDbBoolean('modules', module.scriptName, true);
                    $.bot.loadScript(module.scriptName);
                    $.bot.modules[module.scriptName].isEnabled = true;

                    let hookIndex = $.bot.getHookIndex($.bot.modules[module.scriptName].scriptName, 'initReady');

                    try {
                        if (hookIndex !== -1) {
                            $.bot.getHook(module.scriptName, 'initReady').handler();
                        }

                        $.say($.whisperPrefix(sender) + $.lang.get('init.module.enabled', module.getModuleName()));
                    } catch (ex) {
                        $.log.error('Unable to call initReady for enabled module (' + module.scriptName + '): ' + ex);
                        $.consoleLn("Sending stack trace to error log...");
                        Packages.com.gmt2001.Console.err.printStackTrace(ex.javaException);
                    }
                } else {
                    $.say($.whisperPrefix(sender) + $.lang.get('init.module.404'));
                }
            }

            /*
             * @commandpath module disable [module path] - Disable a module using the path and name of the module
             */
            if ($.equalsIgnoreCase(action, 'disable')) {
                if (subAction === undefined) {
                    $.say($.whisperPrefix(sender) + $.lang.get('init.module.usage.disable'));
                    return;
                }

                if (subAction.indexOf('./core') !== -1 || subAction.indexOf('./lang') !== -1) {
                    return;
                }

                let module = $.bot.getModule(subAction);

                if (module !== undefined) {
                    $.setIniDbBoolean('modules', module.scriptName, false);
                    $.bot.modules[module.scriptName].isEnabled = false;

                    $.say($.whisperPrefix(sender) + $.lang.get('init.module.disabled', module.getModuleName()));

                    if ($.equalsIgnoreCase(module.scriptName, './systems/pointSystem.js')) {
                        let modules = ['./games/adventureSystem.js', './games/roll.js', './games/slotMachine.js', './systems/ticketraffleSystem.js', './systems/raffleSystem.js', './games/gambling.js'],
                            i;

                        for (i in modules) {
                            module = $.bot.getModule(modules[i]);

                            $.bot.modules[modules[i]].isEnabled = false;
                            $.setIniDbBoolean('modules', module.scriptName, false);
                        }
                        $.say($.whisperPrefix(sender) + $.lang.get('init.module.auto-disabled'));
                    }
                } else {
                    $.say($.whisperPrefix(sender) + $.lang.get('init.module.404'));
                }
            }

            /*
             * Panel command.
             */
            if ($.equalsIgnoreCase(action, 'enablesilent')) {
                if (subAction === undefined) {
                    return;
                }

                if (subAction.indexOf('./core') !== -1 || subAction.indexOf('./lang') !== -1) {
                    return;
                }

                let module = $.bot.getModule(subAction);

                if (module !== undefined) {
                    $.setIniDbBoolean('modules', module.scriptName, true);
                    $.bot.loadScript(module.scriptName);
                    $.bot.modules[module.scriptName].isEnabled = true;

                    let hookIndex = $.bot.getHookIndex(module.scriptName, 'initReady');

                    try {
                        if (hookIndex !== -1) {
                            $.bot.getHook(module.scriptName, 'initReady').handler();
                        }
                    } catch (ex) {
                        $.log.error('Unable to call initReady for enabled module (' + module.scriptName + '): ' + ex);
                        $.consoleLn("Sending stack trace to error log...");
                        Packages.com.gmt2001.Console.err.printStackTrace(ex.javaException);
                    }
                }
            }

            /*
             * Panel command.
             */
            if ($.equalsIgnoreCase(action, 'disablesilent')) {
                if (subAction === undefined) {
                    return;
                }

                if (subAction.indexOf('./core') !== -1 || subAction.indexOf('./lang') !== -1) {
                    return;
                }

                let module = $.bot.getModule(subAction);

                if (module !== undefined) {
                    $.setIniDbBoolean('modules', module.scriptName, false);
                    $.bot.modules[module.scriptName].isEnabled = false;

                    if ($.equalsIgnoreCase(module.scriptName, './systems/pointSystem.js')) {
                        let modules = ['./games/adventureSystem.js', './games/roll.js', './games/slotMachine.js', './systems/ticketraffleSystem.js', './systems/raffleSystem.js', './games/gambling.js'],
                            i;

                        for (i in modules) {
                            module = $.bot.getModule(modules[i]);

                            $.bot.modules[module.scriptName].isEnabled = false;
                            $.setIniDbBoolean('modules', module.scriptName, false);
                        }
                    }
                }
            }
        }

        /*
         * Panel command.
         */
        if ($.equalsIgnoreCase(command, 'reconnect')) {
            if ($.isBot(sender)) {
                Packages.tv.phantombot.PhantomBot.instance().reconnect();
            }
        }

        /*
         * Panel command.
         */
        if ($.equalsIgnoreCase(command, 'disconnect')) {
            if ($.isBot(sender)) {
                Packages.java.lang.System.exit(0);
            }
        }

        /*
         * @commandpath echo [message] - Send a message as the bot.
         */
        if ($.equalsIgnoreCase(command, 'chat') || $.equalsIgnoreCase(command, 'echo')) {
            if ($.strlen(argsString) > 0) {
                $.say(argsString);
            }
        }
    });

    /*
     * @event initReady
     */
    $.bind('initReady', function() {
        $.registerChatCommand('./core/initCommands.js', 'chat', $.PERMISSION.Admin);
        $.registerChatCommand('./core/initCommands.js', 'module', $.PERMISSION.Admin);
        $.registerChatCommand('./core/initCommands.js', 'echo', $.PERMISSION.Admin);
        $.registerChatCommand('./core/initCommands.js', 'reconnect', $.PERMISSION.Admin);
        $.registerChatCommand('./core/initCommands.js', 'disconnect', $.PERMISSION.Admin);
        $.registerChatCommand('./core/initCommands.js', 'pbcore', $.PERMISSION.Mod);
        $.registerChatSubcommand('pbcore', 'disconnect', $.PERMISSION.Admin);
        $.registerChatSubcommand('pbcore', 'reconnect', $.PERMISSION.Admin);
        $.registerChatSubcommand('pbcore', 'moderate', $.PERMISSION.Mod);
        $.registerChatSubcommand('pbcore', 'forceonline', $.PERMISSION.Mod);
        $.registerChatSubcommand('pbcore', 'forceoffline', $.PERMISSION.Mod);
        $.registerChatSubcommand('pbcore', 'setconnectmessage', $.PERMISSION.Admin);
        $.registerChatSubcommand('pbcore', 'removeconnectmessage', $.PERMISSION.Admin);
        $.registerChatSubcommand('pbcore', 'togglepricecommods', $.PERMISSION.Admin);
        $.registerChatSubcommand('pbcore', 'togglepermcommessage', $.PERMISSION.Admin);
        $.registerChatSubcommand('pbcore', 'togglepricecommessage', $.PERMISSION.Admin);
        $.registerChatSubcommand('pbcore', 'togglecooldownmessage', $.PERMISSION.Admin);
        $.registerChatSubcommand('pbcore', 'togglecustomcommandat', $.PERMISSION.Admin);

        if (useBotName) {
            $.registerChatAlias($.botName.toLowerCase(), 'pbcore', './core/initCommands.js');
        }

        // Say the connected message.
        if (!sentReady) {
            let connectedMsg = $.optIniDbString('settings', 'connectedMsg');
            if (connectedMsg.isPresent()) {
                $.say(connectedMsg.get());
                sentReady = true;
            }
        }
    });
})();
