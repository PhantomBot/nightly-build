/*
 * Copyright (C) 2016-2026 phantombot.github.io/PhantomBot
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * quoteSystem.js
 *
 * Have the bot remember the most epic/derpy oneliners
 */
(function() {

    let quoteMode = $.getSetIniDbBoolean('settings', 'quoteMode', true),
        isRenumbering = false;

    /**
     * @function updateQuote
     * @param {Number} quoteid
     * @param {Array} quote data
     */
    function updateQuote(quoteid, quote) {
        // Specify String() for objects as they were being treated as an object rather than a String on stringify().
        quote[0] = String(quote[0]).replace(/"/g, '\'\'');
        quote[1] = String(quote[1]).replace(/"/g, '\'\'');
        quote[3] = String(quote[3]).replace(/"/g, '\'\'');

        $.inidb.set('quotes', quoteid, JSON.stringify([String(quote[0]), String(quote[1]), String(quote[2]), String(quote[3])]));
        $.panelsocketserver.sendJSONToAll(JSON.stringify({"query_id": "quote_update", "results": "update"}));
    }

    /**
     * @function saveQuote
     * @param {string} username
     * @param {string} quote
     * @returns {Number}
     */
    function saveQuote(username, quote) {
        let newKey = $.getSetIniDbNumber('settings', 'quoteNextId', 0),
            game = (!$.javaString($.getGame($.channelName)).isBlank() ? $.getGame($.channelName) : "Some Game");

        while ($.inidb.exists('quotes', newKey)) {
            newKey++;
        }

        quote = String(quote).replace(/"/g, '\'\'');
        $.inidb.set('quotes', newKey, JSON.stringify([username, quote, $.systemTime(), game + '']));
        $.setIniDbNumber('settings', 'quoteNextId', newKey + 1);
        $.panelsocketserver.sendJSONToAll(JSON.stringify({"query_id": "quote_update", "results": "update"}));
        return newKey;
    }

    function sortCompare(a, b) {
        let numA = parseInt(a),
            numB = parseInt(b);

        return numA - numB;
    }

    function renumberQuotes() {
        if (isRenumbering) {
            return;
        }
        isRenumbering = true;
        let quoteKeys = $.inidb.GetKeyList('quotes', ''),
        quotes = [],
        i;

        quoteKeys.sort(sortCompare);

        for (i in quoteKeys) {
            quotes.push($.getIniDbString('quotes', quoteKeys[i]));
            $.inidb.del('quotes', quoteKeys[i]);
        }

        for (i in quotes) {
            $.inidb.set('quotes', i, quotes[i]);
        }

        $.inidb.set('settings', 'quoteNextId', quotes.length);
        isRenumbering = false;
    }

    /**
     * @function deleteQuote
     * @param {Number} quoteId
     * @returns {Number}
     */
    function deleteQuote(quoteId) {
        if (isRenumbering) {
            return -1;
        }

        if ($.inidb.exists('quotes', quoteId)) {
            $.inidb.del('quotes', quoteId);

            if ($.getSetIniDbBoolean('settings', 'quoteRenumberAfterDelete', true)) {
                renumberQuotes();
            }

            let quotes = $.inidb.GetKeyList('quotes', '');

            $.panelsocketserver.sendJSONToAll(JSON.stringify({"query_id": "quote_update", "results": "update"}));
            return (quotes.length ? quotes.length : 0);
        }

        return -1;
    }

    /**
     * @function getQuote
     * @param quoteId id or search query
     * @returns {Array}
     */
    function getQuote(quoteId) {
        let quote;

        if (!quoteId) {
            quoteId = $.randElement($.inidb.GetKeyList('quotes', ''));
        } else if (isNaN(quoteId)) {
            quoteId = String(quoteId).toLowerCase();
            let quotes = $.inidb.GetKeyValueList('quotes', '');
            let ids = [];
            let searchids = [];
            for (var i = 0; i < quotes.length; i++) {
                ids.push(quotes[i].getKey());
                if (String(quotes[i].getValue()).toLowerCase().indexOf(quoteId) >= 0) {
                    searchids.push(quotes[i].getKey());
                }
            }
            quoteId = searchids.length > 0 ? $.randElement(searchids) : $.randElement(ids);
        }

        quote = $.optIniDbString('quotes', quoteId);
        if (quote.isPresent()) {
            quote = JSON.parse(quote.get());
            quote.push(quoteId);
            return quote;
        }

        return [];
    }

    /**
     * @event command
     * @param event
     */
    $.bind('command', function(event) {
        let sender = event.getSender(),
            command = event.getCommand(),
            args = event.getArgs(),
            quote,
            quoteStr;

        /**
         * @commandpath editquote [id] [user|game|quote] [text] - Edit quotes.
         */
        if ($.equalsIgnoreCase(command, "editquote")) {
            if (args.length < 3) {
                $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.edit.usage'));
                return;
            }

            quote = getQuote(args[0]);
            if (quote.length > 0) {
                if ($.equalsIgnoreCase(args[1], "user")) {
                    $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.edit.user.success', args[0], args[2]));
                    quote[0] = args[2];
                    updateQuote(args[0], quote);
                } else if ($.equalsIgnoreCase(args[1], "game")) {
                    $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.edit.game.success', args[0], args.splice(2).join(' ')));
                    quote[3] = args.splice(2).join(' ');
                    updateQuote(args[0], quote);
                } else if ($.equalsIgnoreCase(args[1], "quote")) {
                    $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.edit.quote.success', args[0], args.splice(2).join(' ')));
                    quote[1] = args.splice(2).join(' ');
                    updateQuote(args[0], quote);
                } else {
                    $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.edit.usage'));
                }
                return;
            }

            $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.edit.404'));
            $.log.event(sender + ' edited quote #' + quote);
            return;
        }

        /**
         * @commandpath quotemodetoggle - toggle between !addquote function modes
         */
        if ($.equalsIgnoreCase(command, 'quotemodetoggle')) {
            if (quoteMode) {
                quoteMode = false;
                $.inidb.set('settings', 'quoteMode', 'false');
                $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.add.usage2'));
                return;
            }

            quoteMode = true;
            $.inidb.set('settings', 'quoteMode', 'true');
            $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.add.usage1'));
            return;

        }

        /**
         * @commandpath addquote [quote text] - Save a quote
         */
        if ($.equalsIgnoreCase(command, 'addquote')) {
            if (quoteMode) {
                if (args.length < 1) {
                    $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.add.usage1'));
                    return;
                }

                quote = args.splice(0).join(' ');
                $.say($.lang.get('quotesystem.add.success', $.viewer.getByLogin(sender).name(), saveQuote(String($.viewer.getByLogin(sender).name()), quote)));
                $.log.event(sender + ' added a quote "' + quote + '".');
                return;
            }
            if (args.length < 2) {
                $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.add.usage2'));
                return;
            }

            let useTwitchNames = $.getIniDbBoolean('settings', 'quoteTwitchNamesToggle', true);
            let target = useTwitchNames ? args[0].toLowerCase() : args[0].substring(0, 1).toUpperCase() + args[0].substring(1).toLowerCase();
            if (useTwitchNames && !$.user.isKnown(target)) {
                $.say($.whisperPrefix(sender) + $.lang.get('common.user.404', target));
                return;
            }

            quote = args.splice(1).join(' ');
            let username = useTwitchNames ? $.viewer.getByLogin(target).name() : target;
            $.say($.lang.get('quotesystem.add.success', username, saveQuote(String(username), quote)));
            $.log.event(sender + ' added a quote "' + quote + '".');
            return;
        }

        /**
         * USED BY THE PANEL
         */
        if ($.equalsIgnoreCase(command, 'addquotesilent')) {
            if (!$.isBot(sender)) {
                return;
            }
            if (args.length < 1) {
                return;
            }

            quote = args.splice(0).join(' ');
            saveQuote(String($.viewer.getByLogin(sender).name()), quote);
            return;
        }

        /**
         * @commandpath delquote [quoteId] - Delete a quote
         */
        if ($.equalsIgnoreCase(command, 'delquote')) {
            if (!args[0] || isNaN(args[0])) {
                $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.del.usage'));
                return;
            }

            let newCount;

            if ((newCount = deleteQuote(args[0])) >= 0) {
                $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.del.success', args[0], newCount));
                $.log.event(sender + ' removed quote with id: ' + args[0]);
                return;
            }

            $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.del.404', args[0]));
            return;
        }

        /**
         * USED BY THE PANEL
         */
        if ($.equalsIgnoreCase(command, 'delquotesilent')) {
            if (!$.isBot(sender)) {
                return;
            }

            if (deleteQuote(args[0]) >= 0) {
                $.log.event(sender + ' removed quote with id: ' + args[0]);
            }
            return;
        }

        /**
         * @commandpath quote [quoteId] - Announce a quote by its Id, omit the id parameter to get a random quote
         */
        if ($.equalsIgnoreCase(command, 'quote')) {
            quote = getQuote(args[0]);
            if (quote.length > 0) {
                let user = $.viewer.getByLogin(quote[0]);
                if (user == null) {
                    user = quote[0];
                } else {
                    user = user.name();
                }
                quoteStr = $.getIniDbString('settings', 'quoteMessage', $.lang.get('quotesystem.get.success'));
                quoteStr = quoteStr.replace('(id)', (quote.length === 5 ? quote[4].toString() : quote[3].toString()))
                                    .replace('(quote)', quote[1])
                                    .replace('(userrank)', $.resolveRank(quote[0]))
                                    .replace('(user)', user)
                                    .replace('(game)', (quote.length === 5 ? quote[3] : "Some Game"))
                                    .replace('(date)', $.getLocalTimeString($.getSetIniDbString('settings', 'quoteDateFormat', 'dd-MM-yyyy'), parseInt(quote[2])));
                $.say(quoteStr);
            } else {
                $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.get.404', (typeof args[0] !== 'undefined' ? args[0] : '')));
            }

            return;
        }

        /**
         * @commandpath quotemessage [message] - Sets the quote string with tags: (id) (quote) (user) (userrank) (game) (date)
         */
        if ($.equalsIgnoreCase(command, 'quotemessage')) {
            if (!args[0]) {
                $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.quotemessage.usage'));
                return;
            }

            quoteStr = args.splice(0).join(' ');
            $.inidb.set('settings', 'quoteMessage', quoteStr);
            $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.quotemessage.success'));
            $.log.event(sender + ' changed the quote message to: ' + quoteStr);
            return;
        }

        /**
         * @commandpath quotedateformat [format] - Sets the date format for the (date) tag in a quote
         */
        if ($.equalsIgnoreCase(command, 'quotedateformat')) {
            if (!args[0]) {
                $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.quotedateformat.usage', $.getSetIniDbString('settings', 'quoteDateFormat', 'dd-MM-yyyy')));
                return;
            }

            quoteStr = args.splice(0).join(' ');
            $.inidb.set('settings', 'quoteDateFormat', quoteStr);
            $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.quotedateformat.success'));
            $.log.event(sender + ' changed the quote date format to: ' + quoteStr);
            return;
        }

        /**
         * @commandpath searchquote [string] - Searches the quotes for a string and returns a list of IDs
         */
        if ($.equalsIgnoreCase(command, 'searchquote')) {
            if (!args[0]) {
                $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.searchquote.usage'));
                return;
            }

            let searchString = args.join(' ');
            if (searchString.length < 1) {
                $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.searchquote.usage'));
                return;
            }

            let matchingKeys = $.inidb.searchByValue('quotes', searchString);
            if (matchingKeys.length === 0) {
                $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.searchquote.404'));
                return;
            }

            $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.searchquote.found', matchingKeys.join(', ')));
            return;
        }

        /**
         * @commandpath quotetwitchnamestoggle - Toggles on and off if quote names need to have been seen in chat before
         */
        if ($.equalsIgnoreCase(command, 'quotetwitchnamestoggle')) {
            let useTwitchNames = $.getIniDbBoolean('settings', 'quoteTwitchNamesToggle');
            if (useTwitchNames) {
                useTwitchNames = false;
                $.inidb.set('settings', 'quoteTwitchNamesToggle', 'false');
                $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.twitchnames-disabled'));
                return;
            }

            useTwitchNames = true;
            $.inidb.set('settings', 'quoteTwitchNamesToggle', 'true');
            $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.twitchnames-enabled'));
            return;
        }

        /**
         * @commandpath quoterenumberingtoggle - Toggles on and off if quotes should be renumbered after deletion
         */
        if ($.equalsIgnoreCase(command, 'quoterenumberingtoggle')) {
            let renumberQuotes = $.getIniDbBoolean('settings', 'quoteRenumberAfterDelete', true);
            $.setIniDbBoolean('settings', 'quoteRenumberAfterDelete', !renumberQuotes);
            $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.renumbering', $.lang.get('common.' + (!renumberQuotes ? 'enabled' : 'disabled'))));
            return;
        }

        /**
         * @commandpath quotedorenumbering - Renumbers all quotes to be sequential starting at 0
         */
        if ($.equalsIgnoreCase(command, 'quotedorenumbering')) {
            renumberQuotes();
            $.say($.whisperPrefix(sender) + $.lang.get('quotesystem.dorenumbering'));
            return;
        }
    });

    /**
     * @event initReady
     */
    $.bind('initReady', function() {
        $.registerChatCommand('./systems/quoteSystem.js', 'quotemodetoggle', $.PERMISSION.Mod);
        $.registerChatCommand('./systems/quoteSystem.js', 'searchquote', $.PERMISSION.Viewer);
        $.registerChatCommand('./systems/quoteSystem.js', 'addquote', $.PERMISSION.Mod);
        $.registerChatCommand('./systems/quoteSystem.js', 'addquotesilent', $.PERMISSION.Admin);
        $.registerChatCommand('./systems/quoteSystem.js', 'delquote', $.PERMISSION.Mod);
        $.registerChatCommand('./systems/quoteSystem.js', 'delquotesilent', $.PERMISSION.Admin);
        $.registerChatCommand('./systems/quoteSystem.js', 'editquote', $.PERMISSION.Mod);
        $.registerChatCommand('./systems/quoteSystem.js', 'quote');
        $.registerChatCommand('./systems/quoteSystem.js', 'quotemessage', $.PERMISSION.Admin);
        $.registerChatCommand('./systems/quoteSystem.js', 'quotedateformat', $.PERMISSION.Admin);
        $.registerChatCommand('./systems/quoteSystem.js', 'quotetwitchnamestoggle', $.PERMISSION.Admin);
        $.registerChatCommand('./systems/quoteSystem.js', 'quoterenumberingtoggle', $.PERMISSION.Admin);
        $.registerChatCommand('./systems/quoteSystem.js', 'quotedorenumbering', $.PERMISSION.Admin);
    });
})();
