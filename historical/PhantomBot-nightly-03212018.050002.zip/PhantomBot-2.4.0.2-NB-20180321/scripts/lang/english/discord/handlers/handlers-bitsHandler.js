$.lang.register('discord.bitshandler.usage', 'Usage: !bitshandler [toggle / message / channel]');
$.lang.register('discord.bitshandler.bits.toggle', 'Bit announcements have been $1.');
$.lang.register('discord.bitshandler.bits.message.usage', 'Usage: !bitshandler message [message] - Tags: (name) (amount)');
$.lang.register('discord.bitshandler.bits.message.set', 'Bits announcements message set to: $1');
$.lang.register('discord.bitshandler.bits.channel.usage', 'Usage: !bitshandler channel [channel name]');
$.lang.register('discord.bitshandler.bits.channel.set', 'Bit announcements will now be made in channel #$1');