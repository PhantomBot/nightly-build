/*
 * Copyright (C) 2016-2026 phantombot.github.io/PhantomBot
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

(function () {
    /*
     * @transformer randomInt
     * @formula (#) a random integer from 1 to 100, inclusive
     * @formula (# a:int, b:int) a random integer from a to b, inclusive
     * @labels twitch discord noevent basic
     * @example Caster: !addcom !lucky Your lucky number is (#)
     * User: !lucky
     * Bot: Your lucky number is 7
     * @example Caster: !addcom !d6 1d6 = [(# 1, 6)]
     * User: !d6
     * Bot: 1d6 = [5]
     */
    function randomInt(args) {
        let match;
        if (!args.args) {
            return {
                result: $.randRange(1, 100),
                cache: false
            };
        } else if ((match = args.args.match(/^(-?\d+),\s?(-?\d+)$/))) {
            return {
                result: $.randRange(parseInt(match[1]), parseInt(match[2])),
                cache: false
            };
        }
    }

    /*
     * @transformer buildArgs
     * @formula (n:int) the n-th argument (escaped by default)
     * @formula (n:int>) all argument text starting at the n-th argument
     * @formula (n:int!) the n-th argument, with trailing escape characters stripped (escaped by default)
     * @formula (n:int=tag:str) the n-th argument, if given, else another tag to replace this one
     * @formula (n:int>=tag:str) all argument text starting at the n-th argument, if given, else another tag to replace this one
     * @formula (n:int!=tag:str) the n-th argument, if given, with trailing escape characters stripped, else another tag to replace this one
     * @formula (n:int>!=tag:str) all argument text starting at the n-th argument, if given, with trailing escape characters stripped, else another tag to replace this one
     * @formula (n:int|default:str) the n-th argument, if given, else a provided default value
     * @formula (n:int>|default:str) all argument text starting at the n-th argument, if given, else a provided default value
     * @formula (n:int!|default:str) the n-th argument, if given, with trailing escape characters stripped, else a provided default value
     * @formula (n:int>!|default:str) all argument text starting at the n-th argument, if given, with trailing escape characters stripped, else a provided default value
     * @labels twitch discord commandevent basic
     * @example Caster: !addcom !love (sender) loves (1).
     * User: !love monkeys
     * Bot: User loves monkeys.
     * @example Caster: !addcom !hello Hello (1=sender)!
     * User: !hello OtherUser
     * Bot: Hello OtherUser!
     * User: !hello
     * Bot: Hello User!
     * @example Caster: !addcom !hug (sender) hugs (1|themself)!
     * User: !hug OtherUser
     * Bot: User hugs OtherUser!
     * User: !hug
     * Bot: User hugs themself!
     * @example Caster: !addcom !hit (sender) hits (1) with (2>).
     * User: !hit OtherUser some rocks
     * Bot: User hits OtherUser with some rocks.
     * @raw sometimes
     * @cached
     */
    function buildArgs(n) {
        return function (args) {
            let arg = args.event.getArgs()[n - 1];
            if (args.argsep.startsWith('>')) {
                args.argsep = args.argsep.substring(1);
                arg = $.parseArgs(args.event.getArguments(), ' ', n, true);
            }
            if (!args.args) {
                return {result: arg !== undefined ? (args.argsep === '!' ? $.transformers.stripTrailingEscape(arg) : arg) : ''};
            } else {
                if (arg !== undefined) {
                    if (args.argsep.startsWith('!')) {
                        arg = $.transformers.stripTrailingEscape(arg);
                    }
                    return {
                        result: arg,
                        cache: true
                    };
                }
                if (args.argsep.startsWith('!')) {
                    args.argsep = args.argsep.substring(1);
                }
                return {
                    result: (args.argsep === '=' ? '(' : '') + $.transformers.escapeTags(args.args) + (args.argsep === '=' ? ')' : ''),
                    raw: args.argsep === '=',
                    cache: true
                };
            }
        };
    }

    /*
     * @transformer delaysay
     * @formula (delaysay delayseconds:int message:str) send the given message to chat, after the given delay
     * @labels twitch discord commandevent commands
     */
    function delaysay(args) {
        let pargs = $.parseArgs(args.args, ' ', 2, true);
        try {
            if (pargs !== null) {
                let delay = parseInt(pargs[0]);
                let argStr = '';

                if (pargs.length > 1) {
                    argStr = pargs[1];
                }

                setTimeout(function () {
                    if (args.platform === 'discord') {
                        $.discord.say(args.event.getDiscordChannel(), argStr);
                    } else {
                        $.say(argStr);
                    }
                }, delay * 1000, 'delaysay ' + delay);
            }
        } catch (e) {
        }

        return {
            result: ''
        };
    }

    /*
     * @transformer discordsay
     * @formula (discordsay discordchannel:str message:str) send the given message to the specified Discord channel, including when triggering from Twitch chat
     * @labels twitch discord commandevent commands
     */
    function discordsay(args) {
        let pargs = $.parseArgs(args.args, ' ', 2, true);
        if (pargs !== null && pargs.length > 1) {
            let channel = $.discordAPI.getChannel(pargs[0]);
            let argStr = pargs[1];

            if (channel !== null) {
                $.discord.say(channel, argStr);
            }
        }

        return {
            result: ''
        };
    }

    /*
     * @transformer echo
     * @formula (echo) all arguments passed to the command
     * @formula (echo!) all arguments passed to the command, with trailing escape characters stripped
     * @labels twitch discord commandevent basic
     * @example Caster: !addcom !echo (echo)
     * User: !echo test test
     * Bot: test test
     */
    function echo(args) {
        return {result: args.event.getArguments() ? (args.argsep === '!' ? $.transformers.stripTrailingEscape(args.event.getArguments()) : args.event.getArguments()) : ''};
    }

    /*
     * @transformer random
     * @formula (random) random user in chat, or the bot's name if chat is empty
     * @labels twitch discord noevent basic
     * @example Caster: !addcom !poke /me pokes (random) with a long wooden stick.
     * User: !poke
     * Bot: /me pokes User2 with a long wooden stick.
     */
    function random(args) {
        if (args.platform === 'discord') {
            return {result: $.discord.username.random()};
        } else {
            try {
                let name = $.username.resolve($.randElement($.users));

                if ($.users.length === 0 || name === null || name === undefined) {
                    name = $.viewer.getByLogin($.botName).name();
                }

                return {result: name};
            } catch (ex) {
                return {result: $.viewer.getByLogin($.botName).name()};
            }
        }
    }

    /*
     * @transformer randomrank
     * @formula (randomrank) random user in chat, or the bot's name if chat is empty; the chosen user's rank is prefixed
     * @labels twitch noevent basic
     * @example Caster: !addcom !poke /me Pokes (randomrank) with a bar of soap.
     * User: !poke
     * Bot: /me Pokes Master User2 with a bar of soap.
     */
    function randomrank() {
        try {
            return {
                result: $.resolveRank($.randElement($.users)),
                cache: false
            };
        } catch (ex) {
            return {result: $.resolveRank($.botName)};
        }
    }

    /*
     * @transformer repeat
     * @formula (repeat n:int, message:str) repeat the message n times (copy/paste)
     * @labels twitch discord noevent basic
     * @note the value of n is limited to a maximum of 30
     * @cached
     */
    function repeat(args) {
        let MAX_COUNTER_VALUE = 30,
                n, match, i, temp;
        if ((match = args.args.match(/^([1-9]\d*),\s?(.*)$/))) {
            if (!match[2]) {
                return {result: ''};
            }
            n = parseInt(match[1]);
            if (n > MAX_COUNTER_VALUE) {
                n = MAX_COUNTER_VALUE;
            }
            if (n < 1) {
                n = 1;
            }
            temp = [];
            for (i = 0; i < n; i++) {
                temp.push(match[2]);
            }
            return {
                result: temp.join(' '),
                cache: true
            };
        }
    }

    /*
     * @transformer twitchsay
     * @formula (twitchsay message:str) send the given message to Twitch chat, including when triggering from Discord
     * @labels twitch discord commandevent commands
     */
    function twitchsay(args) {
        $.say(args.args);

        return {
            result: ''
        };
    }

    let transformers = [
        new $.transformers.transformer('#', ['twitch', 'discord', 'noevent', 'basic'], randomInt),
        new $.transformers.transformer('delaysay', ['twitch', 'discord', 'commandevent', 'basic'], delaysay),
        new $.transformers.transformer('discordsay', ['twitch', 'discord', 'commandevent', 'basic'], discordsay),
        new $.transformers.transformer('echo', ['twitch', 'discord', 'commandevent', 'basic'], echo),
        new $.transformers.transformer('random', ['twitch', 'discord', 'noevent', 'basic'], random),
        new $.transformers.transformer('randomrank', ['twitch', 'noevent', 'basic'], randomrank),
        new $.transformers.transformer('repeat', ['twitch', 'discord', 'noevent', 'basic'], repeat),
        new $.transformers.transformer('twitchsay', ['twitch', 'discord', 'commandevent', 'basic'], twitchsay)
    ];

    for (let i = 1; i <= 9; i++) {
        transformers.push(new $.transformers.transformer($.jsString(i), ['twitch', 'discord', 'commandevent', 'basic'], buildArgs(i)));
    }

    $.transformers.addTransformers(transformers);
})();

