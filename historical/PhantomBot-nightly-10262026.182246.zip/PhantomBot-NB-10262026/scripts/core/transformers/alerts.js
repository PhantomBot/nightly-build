/*
 * Copyright (C) 2016-2026 phantombot.github.io/PhantomBot
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

(function () {
    /*
     * Cancels a command that uses one of these tags while alerts are paused, without taking its cost
     *
     * @param {object} args the arguments of the transformer
     * @returns {object} the transformer result which cancels the command, or undefined if the tag may run
     */
    function cancelIfPaused(args) {
        // Only commands are paused. Messages such as subscription alerts have no command event.
        if (!$.alertPause.isPaused() || args.event === undefined || args.event === null || args.event.getCommand === undefined) {
            return;
        }

        if (args.customArgs !== undefined && args.customArgs !== null && args.customArgs.redemption !== undefined) {
            $.channelpoints.cancelRedemption(args.customArgs.redemption);
        } else if (args.event.getSenderId !== undefined) {
            // A Discord event. Checked on the event because args.platform is not set by every Discord caller.
            let cost = $.discord.getCommandCost(args.event.getCommand());

            if (cost > 0) {
                $.discord.incrUserPoints(args.event.getSenderId(), cost);
            }
        } else {
            $.alertPause.returnCommandPrice(args.event);
        }

        return {cancel: true};
    }

    /*
     * Makes a transformer cancel the command instead of running while alerts are paused
     *
     * @param {function} transformer
     * @returns {function}
     */
    function pausable(transformer) {
        return function (args) {
            return cancelIfPaused(args) || transformer(args);
        };
    }

    /*
     * @transformer alert
     * @formula (alert fileName:str) sends a GIF/video alert to the alerts overlay, fading out after 3 seconds
     * @formula (alert fileName:str, durationSeconds:int) sends a GIF/video alert to the alerts overlay, fading out after durationSeconds, with the audio volume set to 0.8
     * @formula (alert fileName:str, durationSeconds:int, volume:float) sends a GIF/video alert to the alerts overlay, fading out after durationSeconds, with audio volume set on a scale of 0.0-1.0
     * @formula (alert fileName:str, durationSeconds:int, volume:float, css:str) sends a GIF/video alert to the alerts overlay, fading out after durationSeconds, with audio volume set on a scale of 0.0-1.0, and the provided CSS applied to the GIF/video
     * @formula (alert fileName:str, durationSeconds:int, volume:float, css:str, message:str) sends a GIF/video alert to the alerts overlay, fading out after durationSeconds, with audio volume set on a scale of 0.0-1.0, a message under the GIF/video, and the provided CSS applied to the GIF/video and message
     * @labels twitch discord noevent alerts
     * @notes this tag uses the _config/gif-alerts_ folder
     * @notes if an audio file exists next to the GIF/video file with the same fileName but an audio extension (eg. banana.gif and banana.mp3), then the audio file will automatically load and play at the provided volume
     * @notes while alerts are paused with !togglealerts, a command, keyword or redemption that uses this tag is canceled without taking its cost
     * @cancels sometimes
     * @example Caster: !addcom !banana (alert banana.gif)
     * @example Caster: !addcom !bananatext (alert banana.gif, 5, 0.6, font-size:42px;color:#FF00FF, Ring Ring Ring Ring...Banana Phone!)
     */
    function alert(args) {
        let match;
        if ((match = args.args.match(/^([,.\w\W]+)$/))) {
            $.alertspollssocket.alertImage(match[1]);
            return {result: '', cache: false};
        }
    }
    /*
     * @transformer alerttext
     * @formula (alerttext message:str) sends a text alert to the alerts overlay, fading out after 3 seconds
     * @formula (alerttext -d duration:float, message:str) sends a text alert to the alerts overlay, fading out after duration seconds
     * @formula (alerttext -c css:str, message:str) sends a text alert with the specified CSS to the alerts overlay, fading out after 3 seconds
     * @formula (alerttext -d duration:float, -c css:str, message:str) sends a text alert with the specified CSS to the alerts overlay, fading out after duration seconds
     * @labels twitch discord noevent alerts
     * @notes while alerts are paused with !togglealerts, a command, keyword or redemption that uses this tag is canceled without taking its cost
     * @cancels sometimes
     */
    function alerttext(args) {
        let alertText = args.args;
        let alertCSS = null;
        let alertDuration = null;

        if (alertText.includes(',')) {
            if (alertText.trim().substring(0, 2) === '-d') {
                alertDuration = parseInt(alertText.substring(2, alertText.indexOf(',')).trim());
                if (isNaN(alertDuration)) {
                    alertDuration = null;
                }
                alertText = alertText.substring(alertText.indexOf(',') + 1);
            }
            if (alertText.trim().substring(0, 2) === '-c') {
                alertCSS = alertText.substring(2, alertText.indexOf(',')).trim();
                alertText = alertText.substring(alertText.indexOf(',') + 1);
            }
        }

        if (alertText.includes(',')) {
            if (alertText.trim().substring(0, 2) === '-d') {
                alertDuration = parseInt(alertText.substring(2, alertText.indexOf(',')).trim());
                if (isNaN(alertDuration)) {
                    alertDuration = null;
                }
                alertText = alertText.substring(alertText.indexOf(',') + 1);
            }
            if (alertText.trim().substring(0, 2) === '-c') {
                alertCSS = alertText.substring(2, alertText.indexOf(',')).trim();
                alertText = alertText.substring(alertText.indexOf(',') + 1);
            }
        }

        if (alertText.trim().length > 0) {
            if (alertDuration !== null && alertCSS !== null) {
                $.alertspollssocket.alertText(alertText, alertCSS, alertDuration);
            } else if (alertDuration !== null) {
                $.alertspollssocket.alertText(alertText, alertDuration);
            } else if (alertCSS !== null) {
                $.alertspollssocket.alertText(alertText, alertCSS);
            } else {
                $.alertspollssocket.alertText(alertText);
            }
        }
        
        return {result: '', cache: false};
    }

    /*
     * @transformer playsound
     * @formula (playsound hook:str) plays a sound hook on the alerts overlay
     * @formula (playsound hook:str|volume:float) plays a sound hook on the alerts overlay, with audio volume set on a scale of 0.0-1.0
     * @labels twitch discord noevent alerts
     * @notes this tag uses the _config/audio-hooks_ folder
     * @notes while alerts are paused with !togglealerts, a command, keyword or redemption that uses this tag is canceled without taking its cost
     * @cancels sometimes
     * @example Caster: !addcom !good Played sound goodgood (playsound goodgood)
     * @example Caster: !addcom !evil Played sound evil (playsound evillaugh|0.5)
     */
    function playsound(args) {
        let match;
        if ((match = args.args.match(/^([a-zA-Z0-9_\-\s\,\(\)\'\"\~\.]+)([|]([.0-9_]{0,5}))?$/))) {
            if (!$.audioHookExists(match[1])) {
                if (match[1].includes('.')) {
                    match[1] = match[1].substring(0, match[1].lastIndexOf('.'));
                }
                if (!$.audioHookExists(match[1])) {
                    $.log.error('Could not play audio hook: Audio hook does not exist.');
                    return {result: $.lang.get('customcommands.playsound.404', match[1])};
                }
            }
            $.alertspollssocket.triggerAudioPanel(match[1], match[3] !== undefined ? match[3] : -1);
            return {result: '', cache: false};
        }
    }

    let transformers = [
        new $.transformers.transformer('alert', ['twitch', 'discord', 'noevent', 'alerts'], pausable(alert)),
        new $.transformers.transformer('alerttext', ['twitch', 'discord', 'noevent', 'alerts'], pausable(alerttext)),
        new $.transformers.transformer('playsound', ['twitch', 'discord', 'noevent', 'alerts'], pausable(playsound))
    ];

    $.transformers.addTransformers(transformers);
})();
