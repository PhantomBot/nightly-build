/*
 * Copyright (C) 2016-2026 phantombot.github.io/PhantomBot
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/* global helpers, $ */

/**
 * Custom-panel **loader / namespace owner**. Fetches the merged
 * {@code /panel/custom-manifests.json} produced by
 * {@code com.mcawful.CustomPanelManifestCollector}, indexes the {@code cards} array, and
 * dispatches a {@code pbCustomManifestsLoaded} {@code CustomEvent} on {@code document} that
 * the sibling files (nav, cards, modals) consume.
 *
 * <p>Owns the {@code window.__pbCustomPanel__} namespace — every other file in the
 * {@code customPanel*} family reads constants, shared state, and shared helpers from there
 * (and modal files register their opener via {@code ns.openSettingsModal} /
 * {@code ns.openDetailsModal}). Defensive {@code ||} initialization means script load order
 * is forgiving, but the canonical order in {@code index.html} is loader → modals → nav →
 * cards so this file's defaults always win.</p>
 *
 * <p>Public API: {@code window.initCustomPanelNav()} — call once after panel websocket auth
 * completes (from {@code js/index.js}). Idempotent; repeat calls after the first are ignored.</p>
 *
 * <p>Panel Users: {@code ns.panelSectionAccess} / {@code panelSectionCanWrite} /
 * {@code requirePanelSectionWrite} mirror Settings → Panel Users
 * section permissions for manifest {@code nav.section} and {@code cards.section}.</p>
 *
 * @author mcawful
 */
(function () {
    const ns = window.__pbCustomPanel__ = window.__pbCustomPanel__ || {};

    ns.loaded = ns.loaded || false;
    ns.cardsBySection = ns.cardsBySection || {};
    ns.cardsById = ns.cardsById || {};
    ns.EVENTS = ns.EVENTS || {
        MANIFESTS_LOADED: 'pbCustomManifestsLoaded',
        CARD_SETTINGS_SAVED: 'pbCustomCardSettingsSaved'
    };
    ns.PANEL_SETTINGS_SAVED_WS_ARG = ns.PANEL_SETTINGS_SAVED_WS_ARG || 'panel-settings-saved';
    ns.LOAD_TIMEOUT_MS = ns.LOAD_TIMEOUT_MS || 8000;
    ns.SAVE_TIMEOUT_MS = ns.SAVE_TIMEOUT_MS || 8000;
    ns.MANIFEST_FETCH_TIMEOUT_MS = ns.MANIFEST_FETCH_TIMEOUT_MS || 15000;
    ns.TEXTAREA_DEFAULT_MAX_LEN = ns.TEXTAREA_DEFAULT_MAX_LEN || 480;
    ns.DEFAULT_PERMISSION_GROUP_ID = ns.DEFAULT_PERMISSION_GROUP_ID != null ? ns.DEFAULT_PERMISSION_GROUP_ID : 7;
    ns.DEFAULT_CARD_SECTION = ns.DEFAULT_CARD_SECTION || 'games';
    ns.READ_ONLY_PANEL_TITLE = ns.READ_ONLY_PANEL_TITLE || 'Read-only panel user (no changes allowed).';

    const PANEL_SECTION_ALIASES = {
        'keywords': 'keywords & emotes',
        'overlay': 'stream overlay'
    };

    /**
     * Maps manifest {@code nav.section} / {@code cards.section} keys to Panel Users section names.
     *
     * @param {string} section manifest section (e.g. {@code "extra"}, {@code "games"})
     * @returns {string} normalized section name for permission lookup
     */
    function normalizePanelSectionName(section) {
        const key = String(section || 'extra').toLowerCase();
        return PANEL_SECTION_ALIASES[key] || key;
    }

    /**
     * Access level a user's permission rows record for one section, without the config-user
     * shortcut. Used where the read-only botlogin variants must not count as writers.
     *
     * @param {Array<object>} rows {@code helpers.currentPanelUserData.permission}
     * @param {string} section manifest section key
     * @returns {'write'|'read'|'none'}
     */
    function sectionRowAccess(rows, section) {
        const permKey = normalizePanelSectionName(section);
        if (!Array.isArray(rows)) {
            return 'none';
        }
        const row = rows.find(function (p) {
            return p && p.section === permKey;
        });
        if (!row) {
            return 'none';
        }
        if (row.permission === 'Full Access') {
            return 'write';
        }
        if (row.permission === 'Read Only') {
            return 'read';
        }
        return 'none';
    }

    /**
     * Panel-user access for a stock sidebar section (matches Settings → Panel Users).
     *
     * @param {string} section manifest section key
     * @returns {'write'|'read'|'none'}
     */
    ns.panelSectionAccess = function (section) {
        if (typeof helpers === 'undefined' || !helpers.currentPanelUserData) {
            return 'write';
        }
        if (helpers.currentPanelUserData.userType === 'CONFIG') {
            return 'write';
        }
        return sectionRowAccess(helpers.currentPanelUserData.permission, section);
    };

    /**
     * @param {string} section manifest section key
     * @returns {boolean} whether the user may change settings, toggles, or other writes
     */
    ns.panelSectionCanWrite = function (section) {
        return ns.panelSectionAccess(section) === 'write';
    };

    /**
     * @param {object} card manifest card entry
     * @returns {string} normalized {@code cards.section} (defaults to {@code games})
     */
    ns.cardManifestSection = function (card) {
        const s = card && card.section;
        return s ? String(s).toLowerCase() : ns.DEFAULT_CARD_SECTION;
    };

    /**
     * Same toast as stock {@code global.js} / websocket {@code permission} notifications when a
     * read-only Panel User attempts a write (throttled via {@code helpers.isPermissionErrorRunning}).
     */
    ns.notifyPanelWriteDenied = function () {
        if (typeof helpers === 'undefined' || typeof toastr === 'undefined') {
            return;
        }
        if (helpers.isPermissionErrorRunning) {
            return;
        }
        helpers.isPermissionErrorRunning = true;
        toastr.error(
            'You are missing the required permissions to complete this operation!',
            'Permissions error'
        );
        helpers.sleep(5000).then(function () {
            helpers.isPermissionErrorRunning = false;
        });
    };

    /**
     * @param {string} section manifest section key
     * @returns {boolean} {@code true} when the user may write; otherwise shows the permission toast
     */
    ns.requirePanelSectionWrite = function (section) {
        if (!ns.panelSectionCanWrite(section)) {
            ns.notifyPanelWriteDenied();
            return false;
        }
        return true;
    };

    /**
     * Panel websocket callback ids must be unique while a request is in flight: a request the
     * bot never answers (watchdog timeout, permission denial) leaves its id registered in
     * {@code index.js}, and {@code generateCallBack} refuses to register a second callback under
     * the same id, so a retry would be sent without a completion handler.
     *
     * @param {string} prefix stable id prefix, already including the card id where relevant
     * @returns {string}
     */
    ns.uniqueCallbackId = ns.uniqueCallbackId || function (prefix) {
        return prefix + '_' + Date.now();
    };

    let stylesInjected = false;
    let ran = false;

    /**
     * Defines whether {@code settingsModal} is "actionable" — i.e. has a title and at least
     * one declarative field (flat or accordion).
     *
     * @param {object} sm settingsModal block from a canonical card entry
     * @returns {boolean}
     */
    function settingsModalHasContent(sm) {
        if (!sm || typeof sm !== 'object') {
            return false;
        }
        const hasFlat = Array.isArray(sm.fields) && sm.fields.length > 0;
        const hasSec = Array.isArray(sm.sections) && sm.sections.length > 0;
        return !!sm.title && (hasFlat || hasSec);
    }
    ns.settingsModalHasContent = settingsModalHasContent;

    /**
     * @param {object} card canonical card entry
     * @returns {boolean} whether the card has a usable {@code settingsModal}
     */
    ns.cardHasSettings = function (card) {
        if (!card) {
            return false;
        }
        return settingsModalHasContent(card.settingsModal);
    };

    /**
     * @param {object} card canonical card entry
     * @returns {boolean} whether the card declares read-only {@code detailsModal} content
     */
    ns.cardHasDetailsModal = function (card) {
        const dm = card && card.detailsModal;
        return !!(dm && typeof dm.content === 'string' && dm.content.trim().length > 0);
    };

    /**
     * Injects a single small {@code <style>} block once, the first time any custom UI is
     * rendered. If {@code #pb-custom-panel-styles} already exists (e.g. hot navigation),
     * marks injection complete without duplicating the block. Keeps stock CSS files
     * unmodified; nothing is added to the DOM if no manifests load. Used by the nav file
     * (sidebar dividers) and the cards file (cards-row dividers).
     */
    ns.ensureStylesInjected = function () {
        if (stylesInjected) {
            return;
        }
        if (document.getElementById('pb-custom-panel-styles')) {
            stylesInjected = true;
            return;
        }
        stylesInjected = true;
        const style = document.createElement('style');
        style.id = 'pb-custom-panel-styles';
        style.textContent = [
            '.pb-custom-nav-divider {',
            '    list-style: none;',
            '    margin: 6px 10px 2px 10px;',
            '    padding: 4px 4px 2px 4px;',
            '    border-top: 1px solid rgba(255,255,255,0.08);',
            '    color: #8aa4b1;',
            '    font-size: 10px;',
            '    font-weight: 600;',
            '    text-transform: uppercase;',
            '    letter-spacing: 1px;',
            '    pointer-events: none;',
            '    user-select: none;',
            '}',
            '.pb-custom-cards-divider {',
            '    margin: 16px 0 6px 0;',
            '    padding: 8px 0 4px 0;',
            '    border-top: 1px solid rgba(0,0,0,0.08);',
            '    color: #6c757d;',
            '    font-size: 13px;',
            '    font-weight: 600;',
            '    text-transform: uppercase;',
            '    letter-spacing: 1px;',
            '}',
            '.pb-custom-cards-divider .fa {',
            '    margin-right: 6px;',
            '}',
            '.pb-custom-card-tool-btn {',
            '    margin-bottom: 7px;',
            '}',
            '.pb-custom-card-readonly-toggle,',
            '.pb-custom-card-readonly-settings {',
            '    cursor: not-allowed;',
            '}',
            '.pb-custom-card-readonly-toggle .slider {',
            '    opacity: 0.75;',
            '}',
            '/* Equal-height community cards: BS3 float rows stagger when card bodies differ in height. */',
            '.pb-custom-cards-mount.row {',
            '    display: flex;',
            '    flex-wrap: wrap;',
            '    align-items: stretch;',
            '}',
            '.pb-custom-cards-mount.row:before,',
            '.pb-custom-cards-mount.row:after {',
            '    display: none;',
            '}',
            '.pb-custom-cards-mount > .col-md-12 {',
            '    flex: 0 0 100%;',
            '    max-width: 100%;',
            '}',
            '@media (min-width: 992px) {',
            '    .pb-custom-cards-mount > .col-md-4 {',
            '        display: flex;',
            '        flex-direction: column;',
            '    }',
            '    .pb-custom-cards-mount > .col-md-4 > .box,',
            '    .pb-custom-cards-mount > .col-md-4 > .box > form {',
            '        flex: 1 1 auto;',
            '        display: flex;',
            '        flex-direction: column;',
            '        min-height: 0;',
            '    }',
            '    .pb-custom-cards-mount > .col-md-4 > .box {',
            '        width: 100%;',
            '    }',
            '    .pb-custom-cards-mount > .col-md-4 .box-body {',
            '        flex: 1 1 auto;',
            '    }',
            '}',
            '.pb-custom-checkbox-group {',
            '    margin-bottom: 14px;',
            '}',
            '.pb-custom-checkbox-group-label {',
            '    display: block;',
            '    margin-bottom: 6px;',
            '    font-weight: 600;',
            '}',
            '.pb-custom-checkbox-group-help {',
            '    margin-bottom: 6px;',
            '    font-size: 0.9em;',
            '    opacity: 0.75;',
            '}',
            '.pb-custom-checkbox-group-items {',
            '    display: flex;',
            '    flex-wrap: wrap;',
            '    column-gap: 24px;',
            '    row-gap: 4px;',
            '    align-items: center;',
            '}',
            '.pb-custom-checkbox-group-items > .pretty {',
            '    margin-right: 0;',
            '}'
        ].join('\n');
        document.head.appendChild(style);
    };

    /**
     * Populates {@code ns.cardsById} and {@code ns.cardsBySection} from a canonical card array.
     * Cards missing required fields are dropped silently — the backend already warn-logs them
     * via {@code com.mcawful.CustomPanelManifestCollector}.
     *
     * @param {Array<object>} cards canonical card entries from the merged manifest response
     */
    function indexCards(cards) {
        ns.cardsBySection = {};
        ns.cardsById = {};
        if (!Array.isArray(cards)) {
            return;
        }
        cards.forEach(function (card) {
            if (!card || !card.section || !card.id || !card.title) {
                return;
            }
            ns.cardsById[card.id] = card;
            const section = String(card.section).toLowerCase();
            if (!ns.cardsBySection[section]) {
                ns.cardsBySection[section] = [];
            }
            ns.cardsBySection[section].push(card);
        });
    }

    /**
     * Section {@code index.js} stamps on the next websocket message (see {@code sendToSocket}).
     *
     * @returns {string} empty until the first page has finished loading
     */
    function currentSocketSection() {
        const cp = typeof $.currentPage === 'function' ? $.currentPage() : null;
        return cp ? (cp.panelSection || cp.folder || '') : '';
    }

    /**
     * Asks the bot to scan {@code scripts/custom} for newly-dropped modules so the UI we just
     * rendered isn't pointing at scriptPaths Rhino doesn't know about yet. Idempotent and
     * silent on the bot side; the per-file load log still lands in the bot console.
     *
     * <p>{@code socket.sendCommand} is gated server-side on Full Access for the section of the
     * current page (the dashboard at login), and a denial produces a "Permissions error" toast
     * plus an error line in the bot console. So the scan is only sent when the user's own
     * permission rows grant Full Access on that section: the main panel account and Panel Users
     * with Full Access qualify; the read-only botlogin variants and read-only Panel Users do not.
     * Both the user record and the first page load arrive asynchronously after auth, so wait for
     * them; {@code helpers.loadCurrentUserInfo} either fills the record or signs the page out.</p>
     */
    function scheduleCustomScriptScan() {
        if (typeof helpers === 'undefined' || typeof helpers.promisePoll !== 'function') {
            return;
        }

        helpers.promisePoll(function () {
            return !!helpers.currentPanelUserData && currentSocketSection() !== '';
        }, {pollIntervalMs: 250}).then(function () {
            const section = currentSocketSection();

            if (sectionRowAccess(helpers.currentPanelUserData.permission, section) !== 'write') {
                helpers.log('Custom panel: skipping reloadcustom scan (no Full Access on section "' + section + '")', helpers.LOG_TYPE.DEBUG);
                return;
            }

            if (typeof socket !== 'undefined' && socket && typeof socket.sendCommand === 'function') {
                socket.sendCommand('pb_custom_panel_scan', 'reloadcustom silent', function () {});
            }
        });
    }

    /**
     * Indexes the merged manifest data (empty when the fetch failed) and dispatches
     * {@code pbCustomManifestsLoaded}, so sibling files and any card mount waiting on the event
     * run exactly once per session whether or not the fetch succeeded.
     *
     * @param {Array<object>} navList canonical nav entries
     * @param {Array<object>} cardList canonical card entries
     */
    function publishManifests(navList, cardList) {
        indexCards(cardList);
        ns.loaded = true;

        if (typeof document !== 'undefined' && typeof CustomEvent === 'function') {
            document.dispatchEvent(new CustomEvent(ns.EVENTS.MANIFESTS_LOADED, {
                bubbles: true,
                detail: {nav: navList, cards: cardList}
            }));
        }
    }

    /**
     * Public entry point invoked once from {@code js/index.js} after the panel websocket
     * finishes authenticating. Fetches the merged manifest JSON, indexes {@code cards}, and
     * dispatches {@code pbCustomManifestsLoaded} on {@code document} so sibling files (nav,
     * cards) can react. Repeat calls after the first are ignored, so it is safe to call from
     * any post-login hook.
     */
    window.initCustomPanelNav = function () {
        if (ran) {
            return;
        }
        ran = true;

        $.ajax({
            url: 'custom-manifests.json',
            type: 'GET',
            dataType: 'json',
            timeout: ns.MANIFEST_FETCH_TIMEOUT_MS,
            success: function (data) {
                if (!data) {
                    publishManifests([], []);
                    return;
                }

                publishManifests(Array.isArray(data.nav) ? data.nav : [], Array.isArray(data.cards) ? data.cards : []);
                scheduleCustomScriptScan();
            },
            error: function (xhr, status, err) {
                helpers.log('Custom panel manifest not loaded (' + status + '): ' + (err || ''), helpers.LOG_TYPE.DEBUG);
                publishManifests([], []);
            }
        });
    };
}());
