/**
 * This module is to handle online and offline events from Twitch.
 */
(function() {
	var onlineToggle = $.getSetIniDbBoolean('discordSettings', 'onlineToggle', false),
	    onlineMessage = $.getSetIniDbString('discordSettings', 'onlineMessage', '(name) just went online on Twitch! (url)'),
	    gameToggle = $.getSetIniDbBoolean('discordSettings', 'gameToggle', false),
	    gameMessage = $.getSetIniDbString('discordSettings', 'gameMessage', '(name) just changed game on Twitch to (game)! (url)'),
	    channelName = $.getSetIniDbString('discordSettings', 'onlineChannel', ''),
	    timeout = (480 * 6e4);
	    lastEvent = 0;

	/**
	 * @event twitchOnline
	 */  
	$.bind('twitchOnline', function(event) {
		if (onlineToggle === false || channelName == '') {
			return;
		}

		if ($.systemTime() - lastEvent >= timeout) {
			var s = onlineMessage;

			if (s.match(/\(name\)/)) {
				s = $.replace(s, '(name)', $.channelName);
			}

			if (s.match(/\(url\)/)) {
				s = $.replace(s, '(url)', ('https://www.twitch.tv/' + $.channelName));
			}

			if (s.match(/\(game\)/)) {
				s = $.replace(s, '(game)', $.getGame($.channelName));
			}

			if (s.match(/\(title\)/)) {
				s = $.replace(s, '(title)', $.getStatus($.channelName));
			}

			$.discord.say(channelName, s);
			lastEvent = $.systemTime();
		}
	});

	/**
	 * @event twitchGameChange
	 */  
	$.bind('twitchGameChange', function(event) {
		if (gameToggle === false || channelName == '' || $.isOnline($.channelName) == false) {
			return;
		}

		var s = gameMessage;

		if (s.match(/\(name\)/)) {
			s = $.replace(s, '(name)', $.channelName);
		}

		if (s.match(/\(url\)/)) {
			s = $.replace(s, '(url)', ('https://www.twitch.tv/' + $.channelName));
		}

		if (s.match(/\(game\)/)) {
			s = $.replace(s, '(game)', $.getGame($.channelName));
		}

		if (s.match(/\(title\)/)) {
			s = $.replace(s, '(title)', $.getStatus($.channelName));
		}

		if (s.match(/\(uptime\)/)) {
			s = $.replace(s, '(uptime)', $.getStreamUptime($.channelName).toString());
		}

		$.discord.say(channelName, s);
	});

	/**
	 * @event discordCommand
	 */
	$.bind('discordCommand', function(event) {
		var sender = event.getSender(),
            channel = event.getChannel(),
            command = event.getCommand(),
            mention = event.getMention(),
            arguments = event.getArguments(),
            args = event.getArgs(),
            action = args[0],
            subAction = args[1];

        if (command.equalsIgnoreCase('streamhandler')) {
        	if (action === undefined) {
        		$.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.streamhandler.usage'));
        		return;
        	}

        	/**
        	 * @discordcommandpath streamhandler toggleonline - Toggles the stream online announcements.
        	 */
        	if (action.equalsIgnoreCase('toggleonline')) {
        		onlineToggle = !onlineToggle;
        		$.inidb.set('discordSettings', 'onlineToggle', onlineToggle);
        		$.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.streamhandler.online.toggle', (onlineToggle === true ? $.lang.get('common.enabled') : $.lang.get('common.disabled'))));
        	}

        	/**
        	 * @discordcommandpath streamhandler onlinemessage [message] - Sets the stream online announcement message.
        	 */
        	if (action.equalsIgnoreCase('onlinemessage')) {
        		if (subAction === undefined) {
        			$.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.streamhandler.online.message.usage'));
        			return;
        		}

        		onlineMessage = args.slice(1).join(' ');
        		$.inidb.set('discordSettings', 'onlineMessage', onlineMessage);
        		$.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.streamhandler.online.message.set', onlineMessage));
        	}

        	/**
        	 * @discordcommandpath streamhandler togglegame - Toggles the stream game change announcements.
        	 */
        	if (action.equalsIgnoreCase('togglegame')) {
        		gameToggle = !gameToggle;
        		$.inidb.set('discordSettings', 'gameToggle', gameToggle);
        		$.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.streamhandler.game.toggle', (gameToggle === true ? $.lang.get('common.enabled') : $.lang.get('common.disabled')))); 
        	}

        	/**
        	 * @discordcommandpath streamhandler gamemessage [message] - Sets the stream game change announcement message.
        	 */
        	if (action.equalsIgnoreCase('gamemessage')) {
        		if (subAction === undefined) {
        			$.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.streamhandler.game.message.usage'));
        			return;
        		}

        		gameMessage = args.slice(1).join(' ');
        		$.inidb.set('discordSettings', 'gameMessage', gameMessage);
        		$.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.streamhandler.game.message.set', gameMessage));
        	}

        	/**
        	 * @discordcommandpath streamhandler channel [channel name] - Sets the channel that announcements from this module will be said in.
        	 */
        	if (action.equalsIgnoreCase('channel')) {
        		if (subAction === undefined) {
        			$.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.streamhandler.channel.usage'));
        			return;
        		}

        		channelName = subAction.replace('#', '').toLowerCase();
        		$.inidb.set('discordSettings', 'onlineChannel', channelName);
        		$.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.streamhandler.channel.set', channelName));
        	}
        }
	});

	/**
     * @event initReady
     */
    $.bind('initReady', function() {
        if ($.bot.isModuleEnabled('./discord/handlers/streamHandler.js')) {
            $.discord.registerCommand('./discord/handlers/streamHandler.js', 'streamhandler', 1);
            $.discord.registerSubCommand('streamhandler', 'toggleonline', 1);
            $.discord.registerSubCommand('streamhandler', 'onlinemessage', 1);
            $.discord.registerSubCommand('streamhandler', 'togglegame', 1);
            $.discord.registerSubCommand('streamhandler', 'gamemessage', 1);
            $.discord.registerSubCommand('streamhandler', 'channel', 1);

            // $.unbind('initReady'); Needed or not?
        }
    });
})();
