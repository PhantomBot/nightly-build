/*
 * Copyright (C) 2016-2026 phantombot.github.io/PhantomBot
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/* global toastr */

// Function that querys all of the data we need.
$(function () {
    if (helpers.currentPanelUserData.userType !== 'CONFIG') {
        $('[data-removeForNonConfigUser="true"]').remove();
    }

    // Get all module toggles.
    socket.getDBValues('alerts_get_modules', {
        tables: ['modules', 'modules', 'modules', 'modules', 'modules', 'modules', 'modules', 'modules', 'modules', 'modules', 'modules'],
        keys: ['./handlers/followHandler.js', './handlers/subscribeHandler.js', './handlers/bitsHandler.js', './handlers/clipHandler.js',
            './systems/greetingSystem.js', './systems/welcomeSystem.js', './handlers/donationHandler.js', './handlers/raidHandler.js', './handlers/tipeeeStreamHandler.js',
            './handlers/streamElementsHandler.js', './handlers/blueskyHandler.js']
    }, true, function (e) {
        // Handle the settings button.
        let keys = Object.keys(e),
                module = '',
                i;
        for (i = 0; i < keys.length; i++) {
            // Handle the status of the buttons.
            if (!helpers.isTrue(e[keys[i]])) {
                module = keys[i].substring(keys[i].lastIndexOf('/') + 1).replace('.js', '');

                // Handle the switch.
                $('#' + module + 'Toggle').prop('checked', false);
                // Handle the settings button.
                $('#' + module + 'Settings').prop('disabled', true);
                $('#' + module + 'Link').prop('disabled', true);
            }
        }
    });
});

// Function that handlers the loading of events.
$(function () {
    // Toggle for the alert modules.
    $('[data-alert-toggle]').on('change', function () {
        let name = $(this).attr('id'),
                checked = $(this).is(':checked');

        // Handle the module.
        socket.sendCommandSync('alerts_module_toggle', 'module ' + (checked ? 'enablesilent' : 'disablesilent') + ' ' + $(this).data('alert-toggle'), function () {
            // Toggle the settings button.
            $('#' + name.replace('Toggle', 'Settings')).prop('disabled', !checked);
            $('#' + name.replace('Toggle', 'Link')).prop('disabled', !checked);
            // Alert the user.
            toastr.success('Successfully ' + (checked ? 'enabled' : 'disabled') + ' the alert module!');
        });
    });

    // Follow handler settings.
    $('#followHandlerSettings').on('click', function () {
        socket.getDBValues('alerts_follow_get_settings', {
            tables: ['settings', 'settings', 'settings', 'settings'],
            keys: ['followToggle', 'followReward', 'followMessage', 'followDelay']
        }, true, function (e) {
            helpers.getModal('follow-alert', 'Follower Alert Settings', 'Save', $('<form/>', {
                'role': 'form'
            })
                    // Add the toggle for follow alerts.
                    .append(helpers.getDropdownGroup('follow-toggle', 'Enable Follow Alerts', (helpers.isTrue(e.followToggle) ? 'Yes' : 'No'), ['Yes', 'No'],
                            'If a message should be said in the channel when someone follows. This also toggles the reward.'))
                    // Add the the text area for the follow message.
                    .append(helpers.getTextAreaGroup('follow-message', 'text', 'Follow Message', '', e.followMessage,
                            'Message said when someone follows the channel. Tags: (name), (alert), (playsound), and (reward)', false))
                    // Add the the box for the reward.
                    .append(helpers.getInputGroup('follow-reward', 'number', 'Follow Reward', '', e.followReward,
                            'Reward given to users who follow the channel.'))
                    // Add the the box for the reward
                    .append(helpers.getInputGroup('follow-delay', 'number', 'Follow Delay (Seconds)', '', e.followDelay,
                            'Delay between the follow messages posted in the channel. Minimum is 5 seconds.')),
                    function () { // Callback once the user clicks save.
                        let followToggle = $('#follow-toggle').find(':selected').text() === 'Yes',
                                followMessage = $('#follow-message'),
                                followReward = $('#follow-reward'),
                                followDelay = $('#follow-delay');

                        // Make sure everything has been filled it correctly.
                        switch (false) {
                            case helpers.handleInputString(followMessage):
                            case helpers.handleInputNumber(followReward, 0):
                            case helpers.handleInputNumber(followDelay, 5):
                                break;
                            default:
                                // Update settings.
                                socket.updateDBValues('alerts_follow_update_settings', {
                                    tables: ['settings', 'settings', 'settings', 'settings'],
                                    keys: ['followToggle', 'followReward', 'followMessage', 'followDelay'],
                                    values: [followToggle, followReward.val(), followMessage.val(), followDelay.val()]
                                }, function () {
                                    socket.sendCommand('alerts_follow_update_settings_cmd', 'followerpanelupdate', function () {
                                        // Close the modal.
                                        $('#follow-alert').modal('toggle');
                                        // Alert the user.
                                        toastr.success('Successfully updated the follower alert settings!');
                                    });
                                });
                        }
                    }).modal('toggle');
        });
    });

    // Subscribe handler settings.
    $('#subscribeHandlerSettings').on('click', function () {
        let tables = [];
        let keys = [
            'subscribeMessage', 'reSubscribeMessage', 'giftSubMessage', 'giftAnonSubMessage', 'massGiftSubMessage', 'massAnonGiftSubMessage',
            'subscriberWelcomeToggle', 'reSubscriberWelcomeToggle', 'giftSubWelcomeToggle', 'giftAnonSubWelcomeToggle', 'massGiftSubWelcomeToggle',
            'massAnonGiftSubWelcomeToggle', 'subscribeReward', 'reSubscribeReward', 'giftSubReward', 'massGiftSubReward', 'subEmote', 'subPlans'
        ];
        for (let i = 0; i < keys.length; i++) {
            tables.push('subscribeHandler');
        }
        socket.getDBValues('alerts_subscribe_get_settings', {
            tables: tables,
            keys: keys
        }, true, function (e) {
            helpers.parseJSONValues(e, keys);
            helpers.getModal('subscribe-alert', 'Subscribe Alert Settings', 'Save', $('<form/>', {
                'role': 'form'
            })
                    // Add the div for the col boxes.
                    .append($('<div/>', {
                        'class': 'panel-group',
                        'id': 'accordion'
                    })
                            // Append first collapsible accordion.
                            .append(helpers.getCollapsibleAccordion('main-1', 'New Subscription Settings', $('<form/>', {
                                'role': 'form'
                            })
                                    // Add toggle for normal subscriptions.
                                    .append(helpers.getDropdownGroup('sub-toggle', 'Enable New Subscription Alerts', (helpers.isTrue(e.subscriberWelcomeToggle) ? 'Yes' : 'No'), ['Yes', 'No'],
                                            'If a message should be said in the channel when someone new subscribes. This also toggles the reward.'))
                                    // Append message box for the message
                                    .append(helpers.getTextAreaGroup('sub-msg-1000', 'text', 'New Subscription Message (Tier 1)', '', e.subscribeMessage['1000'],
                                            'Message said when someone new subscribes to the channel at Tier 1.', false))
                                    .append(helpers.getTextAreaGroup('sub-msg-2000', 'text', 'New Subscription Message (Tier 2)', '', e.subscribeMessage['2000'],
                                            'Message said when someone new subscribes to the channel at Tier 2.', false))
                                    .append(helpers.getTextAreaGroup('sub-msg-3000', 'text', 'New Subscription Message (Tier 3)', '', e.subscribeMessage['3000'],
                                            'Message said when someone new subscribes to the channel at Tier 3.', false))
                                    .append(helpers.getTextAreaGroup('sub-msg-prime', 'text', 'New Subscription Message (Prime)', '', e.subscribeMessage['Prime'],
                                            'Message said when someone new subscribes to the channel with Prime.', false))
                                    // Appen the reward box
                                    .append(helpers.getInputGroup('sub-reward-1000', 'number', 'New Subscription Reward (Tier 1)', '', e.subscribeReward['1000'],
                                            'Points reward given when someone new subscribes to the channel at Tier 1.'))
                                    .append(helpers.getInputGroup('sub-reward-2000', 'number', 'New Subscription Reward (Tier 2)', '', e.subscribeReward['2000'],
                                            'Points reward given when someone new subscribes to the channel at Tier 2.'))
                                    .append(helpers.getInputGroup('sub-reward-3000', 'number', 'New Subscription Reward (Tier 3)', '', e.subscribeReward['3000'],
                                            'Points reward given when someone new subscribes to the channel at Tier 3.'))
                                    .append(helpers.getInputGroup('sub-reward-prime', 'number', 'New Subscription Reward (Prime)', '', e.subscribeReward['Prime'],
                                            'Points reward given when someone new subscribes to the channel with Prime.'))
                                    ))
                            // Append third collapsible accordion.
                            .append(helpers.getCollapsibleAccordion('main-3', 'Re-subscription Settings', $('<form/>', {
                                'role': 'form'
                            })
                                    // Add toggle for resubscriptions.
                                    .append(helpers.getDropdownGroup('resub-toggle', 'Enable Re-subscription Alerts', (helpers.isTrue(e.reSubscriberWelcomeToggle) ? 'Yes' : 'No'), ['Yes', 'No'],
                                            'If a message should be said in the channel when someone re-subscribes. This also toggles the reward.'))
                                    // Append message box for the message
                                    .append(helpers.getTextAreaGroup('resub-msg-1000', 'text', 'Re-subscription Message (Tier 1)', '', e.reSubscribeMessage['1000'],
                                            'Message said when someone re-subscribes to the channel at Tier 1.', false))
                                    .append(helpers.getTextAreaGroup('resub-msg-2000', 'text', 'Re-subscription Message (Tier 2)', '', e.reSubscribeMessage['2000'],
                                            'Message said when someone re-subscribes to the channel at Tier 2.', false))
                                    .append(helpers.getTextAreaGroup('resub-msg-3000', 'text', 'Re-subscription Message (Tier 3)', '', e.reSubscribeMessage['3000'],
                                            'Message said when someone re-subscribes to the channel at Tier 3.', false))
                                    .append(helpers.getTextAreaGroup('resub-msg-prime', 'text', 'Re-subscription Message (Prime)', '', e.reSubscribeMessage['Prime'],
                                            'Message said when someone re-subscribes to the channel with Prime.', false))
                                    // Appen the reward box
                                    .append(helpers.getInputGroup('resub-reward-1000', 'number', 'Re-subscription Reward (Tier 1)', '', e.reSubscribeReward['1000'],
                                            'Points reward given when someone re-subscribes to the channel at Tier 1.'))
                                    .append(helpers.getInputGroup('resub-reward-2000', 'number', 'Re-subscription Reward (Tier 2)', '', e.reSubscribeReward['2000'],
                                            'Points reward given when someone re-subscribes to the channel at Tier 2.'))
                                    .append(helpers.getInputGroup('resub-reward-3000', 'number', 'Re-subscription Reward (Tier 3)', '', e.reSubscribeReward['3000'],
                                            'Points reward given when someone re-subscribes to the channel at Tier 3.'))
                                    .append(helpers.getInputGroup('resub-reward-prime', 'number', 'Re-subscription Reward (Prime)', '', e.reSubscribeReward['Prime'],
                                            'Points reward given when someone re-subscribes to the channel with Prime.'))
                                    ))
                            // Append forth collapsible accordion.
                            .append(helpers.getCollapsibleAccordion('main-4', 'Gift Subscription Settings', $('<form/>', {
                                'role': 'form'
                            })
                                    // Add toggle for gifted subscriptions.
                                    .append(helpers.getDropdownGroup('giftsub-toggle', 'Enable Gift Subscription Alerts', (helpers.isTrue(e.giftSubWelcomeToggle) ? 'Yes' : 'No'), ['Yes', 'No'],
                                            'If a message should be said in the channel when someone gifts a subscription. This also toggles the reward.'))
                                    // Append message box for the message
                                    .append(helpers.getTextAreaGroup('giftsub-msg-1000', 'text', 'Gift Subscription Message (Tier 1)', '', e.giftSubMessage['1000'],
                                            'Message said when someone gifts a subscription to the channel at Tier 1.', false))
                                    .append(helpers.getTextAreaGroup('giftsub-msg-2000', 'text', 'Gift Subscription Message (Tier 2)', '', e.giftSubMessage['2000'],
                                            'Message said when someone gifts a subscription to the channel at Tier 2.', false))
                                    .append(helpers.getTextAreaGroup('giftsub-msg-3000', 'text', 'Gift Subscription Message (Tier 3)', '', e.giftSubMessage['3000'],
                                            'Message said when someone gifts a subscription to the channel at Tier 3.', false))
                                    // Appen the reward box
                                    .append(helpers.getInputGroup('giftsub-reward-1000', 'number', 'Gift Subscription Reward (Tier 1)', '', e.giftSubReward['1000'],
                                            'Points reward given to someone who gifts a subscription to the channel at Tier 1.'))
                                    .append(helpers.getInputGroup('giftsub-reward-2000', 'number', 'Gift Subscription Reward (Tier 2)', '', e.giftSubReward['2000'],
                                            'Points reward given to someone who gifts a subscription to the channel at Tier 2.'))
                                    .append(helpers.getInputGroup('giftsub-reward-3000', 'number', 'Gift Subscription Reward (Tier 3)', '', e.giftSubReward['3000'],
                                            'Points reward given to someone who gifts a subscription to the channel at Tier 3.'))
                                    ))
                            // Append fith collapsible accordion.
                            .append(helpers.getCollapsibleAccordion('main-5', 'Anonymous Gift Subscription Settings', $('<form/>', {
                                'role': 'form'
                            })
                                    // Add toggle for gifted subscriptions.
                                    .append(helpers.getDropdownGroup('anon-giftsub-toggle', 'Enable Anonymous Gift Subscription Alerts', (helpers.isTrue(e.giftAnonSubWelcomeToggle) ? 'Yes' : 'No'), ['Yes', 'No'],
                                            'If a message should be said in the channel when someone anonymously gifts a subscription.'))
                                    // Append message box for the message
                                    .append(helpers.getTextAreaGroup('anon-giftsub-msg-1000', 'text', 'Anonymous Gift Subscription Message (Tier 1)', '', e.giftAnonSubMessage['1000'],
                                            'Message said when someone anonymously gifts a subscription to the channel at Tier 1.', false))
                                    .append(helpers.getTextAreaGroup('anon-giftsub-msg-2000', 'text', 'Anonymous Gift Subscription Message (Tier 2)', '', e.giftAnonSubMessage['2000'],
                                            'Message said when someone anonymously gifts a subscription to the channel at Tier 2.', false))
                                    .append(helpers.getTextAreaGroup('anon-giftsub-msg-3000', 'text', 'Anonymous Gift Subscription Message (Tier 3)', '', e.giftAnonSubMessage['3000'],
                                            'Message said when someone anonymously gifts a subscription to the channel at Tier 3.', false))
                                    ))
                            // Append sixth collapsible accordion.
                            .append(helpers.getCollapsibleAccordion('main-6', 'Mass/Mystery Gift Subscription Settings', $('<form/>', {
                                'role': 'form'
                            })
                                    // Add toggle for gifted subscriptions.
                                    .append(helpers.getDropdownGroup('mass-giftsub-toggle', 'Enable Mass/Mystery Gift Subscription Alerts', (helpers.isTrue(e.massGiftSubWelcomeToggle) ? 'Yes' : 'No'), ['Yes', 'No'],
                                            'If a message should be said in the channel when someone mass gifts subscriptions. This also toggles the reward.'))
                                    // Append message box for the message
                                    .append(helpers.getTextAreaGroup('mass-giftsub-msg-1000', 'text', 'Mass/Mystery Gift Subscription Message (Tier 1)', '', e.massGiftSubMessage['1000'],
                                            'Message said when someone mass gifts a subscriptions to the channel at Tier 1.', false))
                                    .append(helpers.getTextAreaGroup('mass-giftsub-msg-2000', 'text', 'Mass/Mystery Gift Subscription Message (Tier 2)', '', e.massGiftSubMessage['2000'],
                                            'Message said when someone mass gifts a subscriptions to the channel at Tier 2.', false))
                                    .append(helpers.getTextAreaGroup('mass-giftsub-msg-3000', 'text', 'Mass/Mystery Gift Subscription Message (Tier 3)', '', e.massGiftSubMessage['3000'],
                                            'Message said when someone mass gifts a subscriptions to the channel at Tier 3.', false))
                                    // Appen the reward box
                                    .append(helpers.getInputGroup('mass-giftsub-reward-1000', 'number', 'Mass/Mystery Gift Subscription Reward (Tier 1)', '', e.massGiftSubReward['1000'],
                                            'Points reward given to someone who mass gifts a subscriptions to the channel at Tier 1 (per subscription gifted).'))
                                    .append(helpers.getInputGroup('mass-giftsub-reward-2000', 'number', 'Mass/Mystery Gift Subscription Reward (Tier 2)', '', e.massGiftSubReward['2000'],
                                            'Points reward given to someone who mass gifts a subscriptions to the channel at Tier 2 (per subscription gifted).'))
                                    .append(helpers.getInputGroup('mass-giftsub-reward-3000', 'number', 'Mass/Mystery Gift Subscription Reward (Tier 3)', '', e.massGiftSubReward['3000'],
                                            'Points reward given to someone who mass gifts a subscriptions to the channel at Tier 3 (per subscription gifted).'))
                                    ))
                            // Append seventh collapsible accordion.
                            .append(helpers.getCollapsibleAccordion('main-7', 'Anonymous Mass/Mystery Gift Subscription Settings', $('<form/>', {
                                'role': 'form'
                            })
                                    // Add toggle for gifted subscriptions.
                                    .append(helpers.getDropdownGroup('anon-mass-giftsub-toggle', 'Enable Anonymous Mass/Mystery Gift Subscription Alerts', (helpers.isTrue(e.massAnonGiftSubWelcomeToggle) ? 'Yes' : 'No'), ['Yes', 'No'],
                                            'If a message should be said in the channel when someone anonymously mass gifts subscriptions.'))
                                    // Append message box for the message
                                    .append(helpers.getTextAreaGroup('anon-mass-giftsub-msg-1000', 'text', 'Anonymous Mass/Mystery Gift Subscription Message (Tier 1)', '', e.massAnonGiftSubMessage['1000'],
                                            'Message said when someone anonymously mass gifts a subscriptions to the channel at Tier 1.', false))
                                    .append(helpers.getTextAreaGroup('anon-mass-giftsub-msg-2000', 'text', 'Anonymous Mass/Mystery Gift Subscription Message (Tier 2)', '', e.massAnonGiftSubMessage['2000'],
                                            'Message said when someone anonymously mass gifts a subscriptions to the channel at Tier 2.', false))
                                    .append(helpers.getTextAreaGroup('anon-mass-giftsub-msg-3000', 'text', 'Anonymous Mass/Mystery Gift Subscription Message (Tier 3)', '', e.massAnonGiftSubMessage['3000'],
                                            'Message said when someone anonymously mass gifts a subscriptions to the channel at Tier 3.', false))
                                    ))
                            // Tier settings
                            .append(helpers.getCollapsibleAccordion('main-8', 'Tier Settings', $('<form/>', {
                                'role': 'form'
                            })
                                    // Append sub plan name
                                    .append(helpers.getInputGroup('sub-plan-1000', 'text', 'Subscription Plan Name (Tier 1)', '', e.subPlans['1000'], 'Name given to the Tier 1 plan.'))
                                    .append(helpers.getInputGroup('sub-plan-2000', 'text', 'Subscription Plan Name (Tier 2)', '', e.subPlans['2000'], 'Name given to the Tier 2 plan.'))
                                    .append(helpers.getInputGroup('sub-plan-3000', 'text', 'Subscription Plan Name (Tier 3)', '', e.subPlans['3000'], 'Name given to the Tier 3 plan.'))
                                    .append(helpers.getInputGroup('sub-plan-prime', 'text', 'Subscription Plan Name (Prime)', '', e.subPlans['Prime'], 'Name given to the Prime plan.'))
                                    // Append the emotes box
                                    .append(helpers.getInputGroup('sub-emote-1000', 'text', 'Subscription Emote (Tier 1)', '', e.subEmote['1000'],
                                            'Emote that will replace (customemote) for Tier 1 subscriptions. For individual subscription messages, the emote is repeated for '
                                            + 'the number of months subscribed. For mass subscription messages, the emote is repeated for the number of subscriptions gifted.'))
                                    .append(helpers.getInputGroup('sub-emote-2000', 'text', 'Subscription Emote (Tier 2)', '', e.subEmote['2000'],
                                            'Emote that will replace (customemote) for Tier 2 subscriptions. For individual subscription messages, the emote is repeated for '
                                            + 'the number of months subscribed. For mass subscription messages, the emote is repeated for the number of subscriptions gifted.'))
                                    .append(helpers.getInputGroup('sub-emote-3000', 'text', 'Subscription Emote (Tier 3)', '', e.subEmote['3000'],
                                            'Emote that will replace (customemote) for Tier 3 subscriptions. For individual subscription messages, the emote is repeated for '
                                            + 'the number of months subscribed. For mass subscription messages, the emote is repeated for the number of subscriptions gifted.'))
                                    .append(helpers.getInputGroup('sub-emote-prime', 'text', 'Subscription Emote (Prime)', '', e.subEmote['Prime'],
                                            'Emote that will replace (customemote) for Prime subscriptions. The emote is repeated for the number of months subscribed.'))
                                    ))),
                    function () { // Callback once the user clicks save.
                        let subToggle = $('#sub-toggle').find(':selected').text() === 'Yes',
                                subMsg1000 = $('#sub-msg-1000'),
                                subMsg2000 = $('#sub-msg-2000'),
                                subMsg3000 = $('#sub-msg-3000'),
                                subMsgPrime = $('#sub-msg-prime'),
                                subReward1000 = $('#sub-reward-1000'),
                                subReward2000 = $('#sub-reward-2000'),
                                subReward3000 = $('#sub-reward-3000'),
                                subRewardPrime = $('#sub-reward-prime'),
                                reSubToggle = $('#resub-toggle').find(':selected').text() === 'Yes',
                                reSubMsg1000 = $('#resub-msg-1000'),
                                reSubMsg2000 = $('#resub-msg-2000'),
                                reSubMsg3000 = $('#resub-msg-3000'),
                                reSubMsgPrime = $('#resub-msg-prime'),
                                reSubReward1000 = $('#resub-reward-1000'),
                                reSubReward2000 = $('#resub-reward-2000'),
                                reSubReward3000 = $('#resub-reward-3000'),
                                reSubRewardPrime = $('#resub-reward-prime'),
                                giftSubToggle = $('#giftsub-toggle').find(':selected').text() === 'Yes',
                                giftSubMsg1000 = $('#giftsub-msg-1000'),
                                giftSubMsg2000 = $('#giftsub-msg-2000'),
                                giftSubMsg3000 = $('#giftsub-msg-3000'),
                                giftSubReward1000 = $('#giftsub-reward-1000'),
                                giftSubReward2000 = $('#giftsub-reward-2000'),
                                giftSubReward3000 = $('#giftsub-reward-3000'),
                                anonGiftSubToggle = $('#anon-giftsub-toggle').find(':selected').text() === 'Yes',
                                anonGiftSubMsg1000 = $('#anon-giftsub-msg-1000'),
                                anonGiftSubMsg2000 = $('#anon-giftsub-msg-2000'),
                                anonGiftSubMsg3000 = $('#anon-giftsub-msg-3000'),
                                massGiftSubToggle = $('#mass-giftsub-toggle').find(':selected').text() === 'Yes',
                                massGiftSubMsg1000 = $('#mass-giftsub-msg-1000'),
                                massGiftSubMsg2000 = $('#mass-giftsub-msg-2000'),
                                massGiftSubMsg3000 = $('#mass-giftsub-msg-3000'),
                                massGiftSubReward1000 = $('#mass-giftsub-reward-1000'),
                                massGiftSubReward2000 = $('#mass-giftsub-reward-2000'),
                                massGiftSubReward3000 = $('#mass-giftsub-reward-3000'),
                                anonMassGiftSubToggle = $('#anon-mass-giftsub-toggle').find(':selected').text() === 'Yes',
                                anonMassGiftSubMsg1000 = $('#anon-mass-giftsub-msg-1000'),
                                anonMassGiftSubMsg2000 = $('#anon-mass-giftsub-msg-2000'),
                                anonMassGiftSubMsg3000 = $('#anon-mass-giftsub-msg-3000'),
                                tierOne = $('#sub-plan-1000'),
                                tierTwo = $('#sub-plan-2000'),
                                tierThree = $('#sub-plan-3000'),
                                tierPrime = $('#sub-plan-prime'),
                                subEmote1000 = $('#sub-emote-1000'),
                                subEmote2000 = $('#sub-emote-2000'),
                                subEmote3000 = $('#sub-emote-3000'),
                                subEmotePrime = $('#sub-emote-prime');

                        // Make sure the user has someone in each box.
                        switch (false) {
                            case helpers.handleInputString(subMsg1000):
                            case helpers.handleInputString(subMsg2000):
                            case helpers.handleInputString(subMsg3000):
                            case helpers.handleInputString(subMsgPrime):
                            case helpers.handleInputNumber(subReward1000, 0):
                            case helpers.handleInputNumber(subReward2000, 0):
                            case helpers.handleInputNumber(subReward3000, 0):
                            case helpers.handleInputNumber(subRewardPrime, 0):
                            case helpers.handleInputString(reSubMsg1000):
                            case helpers.handleInputString(reSubMsg2000):
                            case helpers.handleInputString(reSubMsg3000):
                            case helpers.handleInputString(reSubMsgPrime):
                            case helpers.handleInputNumber(reSubReward1000, 0):
                            case helpers.handleInputNumber(reSubReward2000, 0):
                            case helpers.handleInputNumber(reSubReward3000, 0):
                            case helpers.handleInputNumber(reSubRewardPrime, 0):
                            case helpers.handleInputString(giftSubMsg1000):
                            case helpers.handleInputString(giftSubMsg2000):
                            case helpers.handleInputString(giftSubMsg3000):
                            case helpers.handleInputNumber(giftSubReward1000, 0):
                            case helpers.handleInputNumber(giftSubReward2000, 0):
                            case helpers.handleInputNumber(giftSubReward3000, 0):
                            case helpers.handleInputString(anonGiftSubMsg1000):
                            case helpers.handleInputString(anonGiftSubMsg2000):
                            case helpers.handleInputString(anonGiftSubMsg3000):
                            case helpers.handleInputString(massGiftSubMsg1000):
                            case helpers.handleInputString(massGiftSubMsg2000):
                            case helpers.handleInputString(massGiftSubMsg3000):
                            case helpers.handleInputNumber(massGiftSubReward1000, 0):
                            case helpers.handleInputNumber(massGiftSubReward2000, 0):
                            case helpers.handleInputNumber(massGiftSubReward3000, 0):
                            case helpers.handleInputString(anonMassGiftSubMsg1000):
                            case helpers.handleInputString(anonMassGiftSubMsg2000):
                            case helpers.handleInputString(anonMassGiftSubMsg3000):
                            case helpers.handleInputString(tierOne):
                            case helpers.handleInputString(tierTwo):
                            case helpers.handleInputString(tierThree):
                            case helpers.handleInputString(tierPrime):
                                break;
                            default:
                                socket.updateDBValues('alerts_subscribe_update_settings', {
                                    tables: tables,
                                    keys: keys,
                                    values: [
                                        JSON.stringify({'1000': subMsg1000.val(), '2000': subMsg2000.val(), '3000': subMsg3000.val(), 'Prime': subMsgPrime.val()}),
                                        JSON.stringify({'1000': reSubMsg1000.val(), '2000': reSubMsg2000.val(), '3000': reSubMsg3000.val(), 'Prime': reSubMsgPrime.val()}),
                                        JSON.stringify({'1000': giftSubMsg1000.val(), '2000': giftSubMsg2000.val(), '3000': giftSubMsg3000.val()}),
                                        JSON.stringify({'1000': anonGiftSubMsg1000.val(), '2000': anonGiftSubMsg2000.val(), '3000': anonGiftSubMsg3000.val()}),
                                        JSON.stringify({'1000': massGiftSubMsg1000.val(), '2000': massGiftSubMsg2000.val(), '3000': massGiftSubMsg3000.val()}),
                                        JSON.stringify({'1000': anonMassGiftSubMsg1000.val(), '2000': anonMassGiftSubMsg2000.val(), '3000': anonMassGiftSubMsg3000.val()}),
                                        subToggle, reSubToggle, giftSubToggle, anonGiftSubToggle, massGiftSubToggle, anonMassGiftSubToggle,
                                        JSON.stringify({'1000': parseInt(subReward1000.val()), '2000': parseInt(subReward2000.val()), '3000': parseInt(subReward3000.val()), 'Prime': parseInt(subRewardPrime.val())}),
                                        JSON.stringify({'1000': parseInt(reSubReward1000.val()), '2000': parseInt(reSubReward2000.val()), '3000': parseInt(reSubReward3000.val()), 'Prime': parseInt(reSubRewardPrime.val())}),
                                        JSON.stringify({'1000': parseInt(giftSubReward1000.val()), '2000': parseInt(giftSubReward2000.val()), '3000': parseInt(giftSubReward3000.val())}),
                                        JSON.stringify({'1000': parseInt(massGiftSubReward1000.val()), '2000': parseInt(massGiftSubReward2000.val()), '3000': parseInt(massGiftSubReward3000.val())}),
                                        JSON.stringify({'1000': subEmote1000.val(), '2000': subEmote2000.val(), '3000': subEmote3000.val(), 'Prime': subEmotePrime.val()}),
                                        JSON.stringify({'1000': tierOne.val(), '2000': tierTwo.val(), '3000': tierThree.val(), 'Prime': tierPrime.val()})
                                    ]
                                }, function () {
                                    socket.sendCommand('alerts_subscribe_update_settings_cmd', 'subscriberpanelupdate', function () {
                                        // Close the modal.
                                        $('#subscribe-alert').modal('toggle');
                                        // Alert the user.
                                        toastr.success('Successfully updated subscription alert settings!');
                                    });
                                });
                        }
                    }).modal('toggle');
        });
    });

    // Bits alert settings.
    $('#bitsHandlerSettings').on('click', function () {
        socket.getDBValues('alerts_get_bits_settings', {
            tables: ['bitsSettings', 'bitsSettings', 'bitsSettings'],
            keys: ['toggle', 'message', 'minimum']
        }, true, function (e) {
            helpers.getModal('bits-alert', 'Bits Alert Settings', 'Save', $('<form/>', {
                'role': 'form'
            })
                    // Add the toggle for bits alerts.
                    .append(helpers.getDropdownGroup('bits-toggle', 'Enable Bits Alerts', (helpers.isTrue(e.toggle) ? 'Yes' : 'No'), ['Yes', 'No'],
                            'If a message should be said in the channel when someone cheers.'))
                    // Add the the text area for the bits message.
                    .append(helpers.getTextAreaGroup('bits-message', 'text', 'Bits Message', '', e.message,
                            'Message said when someone cheers in the the channel. Tags: (name), (alert), (playsound), (message), and (amount)', false))
                    // Add the box for the reward.
                    .append(helpers.getInputGroup('bits-minimum', 'number', 'Bits Minimum', '', e.minimum, 'Amount of bits needed to trigger the alert.')),
                    function () { // Callback once the user clicks save.
                        let bitsToggle = $('#bits-toggle').find(':selected').text() === 'Yes',
                                bitsMsg = $('#bits-message'),
                                bitsMin = $('#bits-minimum');

                        // Make sure the user has someone in each box.
                        switch (false) {
                            case helpers.handleInputString(bitsMsg):
                            case helpers.handleInputNumber(bitsMin):
                                break;
                            default:
                                socket.updateDBValues('alerts_update_bits_settings', {
                                    tables: ['bitsSettings', 'bitsSettings', 'bitsSettings'],
                                    keys: ['toggle', 'message', 'minimum'],
                                    values: [bitsToggle, bitsMsg.val(), bitsMin.val()]
                                }, function () {
                                    socket.sendCommand('alerts_update_bits_settings_cmd', 'reloadbits', function () {
                                        // Close the modal.
                                        $('#bits-alert').modal('toggle');
                                        // Alert the user.
                                        toastr.success('Successfully updated Bits alert settings!');
                                    });
                                });
                        }

                    }).modal('toggle');
        });
    });

    // Clip alert settings.
    $('#clipHandlerSettings').on('click', function () {
        socket.getDBValues('alerts_get_clip_settings', {
            tables: ['clipsSettings', 'clipsSettings'],
            keys: ['toggle', 'message']
        }, true, function (e) {
            helpers.getModal('clip-alert', 'Clip Alert Settings', 'Save', $('<form/>', {
                'role': 'form'
            })
                    // Add the toggle for clip alerts.
                    .append(helpers.getDropdownGroup('clip-toggle', 'Enable Clip Alerts', (helpers.isTrue(e.toggle) ? 'Yes' : 'No'), ['Yes', 'No'],
                            'If a message should be said in the channel when someone creates a clip.'))
                    // Add the text area for the clips message.
                    .append(helpers.getTextAreaGroup('clip-message', 'text', 'Clip Message', '', e.message,
                            'Message said when someone creates a clip. Tags: (name), (alert), (playsound), (title), and (url)', false)),
                    function () { // Callback once the user clicks save.
                        let clipToggle = $('#clip-toggle').find(':selected').text() === 'Yes',
                                clipMsg = $('#clip-message');

                        // Make sure the user has someone in each box.
                        switch (false) {
                            case helpers.handleInputString(clipMsg):
                                break;
                            default:
                                socket.updateDBValues('alerts_update_clip_settings', {
                                    tables: ['clipsSettings', 'clipsSettings'],
                                    keys: ['toggle', 'message'],
                                    values: [clipToggle, clipMsg.val()]
                                }, function () {
                                    socket.sendCommand('alerts_update_clip_settings_cmd', 'reloadclip', function () {
                                        // Close the modal.
                                        $('#clip-alert').modal('toggle');
                                        // Alert the user.
                                        toastr.success('Successfully updated Clip alert settings!');
                                    });
                                });
                        }
                    }).modal('toggle');
        });
    });

    // Raid settings.
    $('#raidHandlerSettings').on('click', function () {
        socket.getDBValues('alerts_get_raid_settings', {
            tables: ['raidSettings', 'raidSettings', 'raidSettings', 'raidSettings', 'raidSettings', 'raidSettings', 'raidSettings', 'raidSettings'],
            keys: ['raidToggle', 'newRaidIncMessage', 'raidIncMessage', 'raidReward', 'raidOutMessage', 'raidOutSpam', 'raidMinViewers', 'shoutoutapi']
        }, true, function (e) {
            helpers.getModal('raid-alert', 'Raid Alert Settings', 'Save', $('<form/>', {
                'role': 'form'
            })
                    // Add the div for the col boxes.
                    .append($('<div/>', {
                        'class': 'panel-group',
                        'id': 'accordion'
                    })
                            // Append first collapsible accordion.
                            .append(helpers.getCollapsibleAccordion('main-1', 'Incoming Raid Settings', $('<form/>', {
                                'role': 'form'
                            })
                                    // Add the toggle for raid alerts.
                                    .append(helpers.getDropdownGroup('raid-toggle', 'Enable Raid Alerts', (helpers.isTrue(e.raidToggle) ? 'Yes' : 'No'), ['Yes', 'No'],
                                            'If people who raid your channel should be noticed by the bot with a message.'))
                                    // Add the text area for the new raid message.
                                    .append(helpers.getTextAreaGroup('new-raid-message', 'text', 'New Raider Message', '', e.newRaidIncMessage,
                                            'Message said when someone raids your channel for the first time. Tags: (username), (alert), (playsound), (viewers), (url), (reward) and (game)', false))
                                    // Add the text area for the raid message.
                                    .append(helpers.getTextAreaGroup('raid-message', 'text', 'Raider Message', '', e.raidIncMessage,
                                            'Message said when someone raids your channel. Tags: (username), (alert), (playsound), (viewers), (url), (times), (reward) and (game)', false))
                                    // Appen the reward box
                                    .append(helpers.getInputGroup('raid-reward', 'number', 'Raid Reward', '', e.raidReward,
                                            'Reward given to the users who raid your channel.'))
                                    // Appen the min viewers for alerts box
                                    .append(helpers.getInputGroup('raid-min-viewers', 'number', 'Raid Minimum Viewers', '', e.raidMinViewers,
                                            'The minimum amount of viewers to trigger the raid alert. Data will still be saved in history even if minimum viewers is not met.'))
                                    .append(helpers.getDropdownGroup('shoutout-api', 'Enable Shoutout API', (helpers.isTrue(e.shoutoutapi) ? 'Yes' : 'No'), ['Yes', 'No'],
                                            'Enables sending a Twitch /shoutout for the raiding channel. NOTE: Limit of 1 shoutout per 2 minutes. Can not repeat the same channel within 1 hour.')))
                            // Append second collapsible accordion.
                            .append(helpers.getCollapsibleAccordion('main-2', 'Outgoing Raid Settings', $('<form/>', {
                                'role': 'form'
                            })
                                    // Add the text area for the new raid message.
                                    .append(helpers.getTextAreaGroup('out-raid-message', 'text', 'Raiding Message', '', e.raidOutMessage,
                                            'Message said in chat when you use the !raid command to raid a channel. Tags: (username) and (url)', false))
                                    // Appen the spam box
                                    .append(helpers.getInputGroup('raid-spam', 'number', 'Raiding Message Spam', '', e.raidOutSpam,
                                            'How many times the message when using the !raid command will be said in the chat. Maximum is 10 times.')))))),
                    function () {
                        let raidToggle = $('#raid-toggle').find(':selected').text() === 'Yes',
                                raidNewMsg = $('#new-raid-message'),
                                raidMsg = $('#raid-message'),
                                raidReward = $('#raid-reward'),
                                raidOutMsg = $('#out-raid-message'),
                                raidMsgSpam = $('#raid-spam'),
                                raidMinViewers = $('#raid-min-viewers'),
                                shoutoutApi = $('#shoutout-api').find(':selected').text() === 'Yes';

                        switch (false) {
                            case helpers.handleInputString(raidNewMsg):
                            case helpers.handleInputString(raidMsg):
                            case helpers.handleInputNumber(raidReward, 0):
                            case helpers.handleInputString(raidOutMsg):
                            case helpers.handleInputNumber(raidMsgSpam, 1, 10):
                            case helpers.handleInputNumber(raidMinViewers, 0):
                                break;
                            default:
                                socket.updateDBValues('raid_setting_update', {
                                    tables: ['raidSettings', 'raidSettings', 'raidSettings', 'raidSettings', 'raidSettings', 'raidSettings', 'raidSettings', 'raidSettings'],
                                    keys: ['raidToggle', 'newRaidIncMessage', 'raidIncMessage', 'raidReward', 'raidOutMessage', 'raidOutSpam', 'raidMinViewers', 'shoutoutapi'],
                                    values: [raidToggle, raidNewMsg.val(), raidMsg.val(), raidReward.val(), raidOutMsg.val(), raidMsgSpam.val(), raidMinViewers.val(), shoutoutApi]
                                }, function () {
                                    socket.sendCommand('raid_setting_update_cmd', 'reloadraid', function () {
                                        // Alert the user.
                                        toastr.success('Successfully updated the raid settings!');
                                        // Close the modal.
                                        $('#raid-alert').modal('toggle');
                                    });
                                });
                        }
                    }).modal('toggle');
        });
    });

    // Welcome esettings.
    $('#welcomeSystemSettings').on('click', function () {
        const updateDisabled = function (disabledUsers, welcomeDisabled, callback) {
            let addTables = [],
                    addKeys = [],
                    addVals = [],
                    delTables = [],
                    delKeys = [];

            let previouslyDisabled = {};
            for (let row of disabledUsers) {
                previouslyDisabled[row.key] = true;
            }
            let newDisabledUsers = welcomeDisabled.map(function (name) {
                return name.replace(/[^a-zA-Z0-9_\n]/g, '').toLowerCase();
            });
            for (let newDisabledUser of newDisabledUsers) {
                if (!newDisabledUser) {
                    continue;
                }
                if (previouslyDisabled.hasOwnProperty(newDisabledUser)) {
                    delete previouslyDisabled[newDisabledUser];
                } else {
                    addTables.push('welcome_disabled_users');
                    addKeys.push(newDisabledUser);
                    addVals.push('true');
                }
            }
            for (let disabledUser in previouslyDisabled) {
                if (previouslyDisabled.hasOwnProperty(disabledUser)) {
                    delTables.push('welcome_disabled_users');
                    delKeys.push(disabledUser);
                }
            }

            const add = function (cb) {
                if (addKeys.length) {
                    socket.updateDBValues('alerts_add_welcome_disabled', {
                        tables: addTables,
                        keys: addKeys,
                        values: addVals
                    }, cb);
                } else {
                    cb();
                }
            };

            const remove = function (cb) {
                if (delKeys.length) {
                    socket.removeDBValues('alerts_del_welcome_disabled', {
                        tables: delTables,
                        keys: delKeys
                    }, cb);
                } else {
                    cb();
                }
            };

            add(function () {
                remove(callback);
            });
        };

        socket.getDBValues('alerts_get_welcome_settings', {
            tables: ['welcome', 'welcome', 'welcome', 'welcome'],
            keys: ['welcomeEnabled', 'welcomeMessage', 'welcomeMessageFirst', 'cooldown']
        }, true, function (e) {
            socket.getDBTableValues('alerts_get_welcome_disabled_users', 'welcome_disabled_users', function (disabledUsers) {
                let disabledUserOptions = [];
                for (let row of disabledUsers) {
                    disabledUserOptions.push({
                        'name': row.key,
                        'selected': 'true'
                    });
                }
                const modal = helpers.getModal('welcome-alert', 'Welcome Alert Settings', 'Save', $('<form/>', {
                    'role': 'form'
                })
                        // Add the toggle for welcome alerts.
                        .append(helpers.getDropdownGroup('welcome-toggle', 'Enable Welcome Messages', (helpers.isTrue(e.welcomeEnabled) ? 'Yes' : 'No'), ['Yes', 'No'],
                                'If users should be welcomed by the bot when the start chatting.'))
                        // Add the input for welcome message.
                        .append(helpers.getInputGroup('welcome-message', 'text', 'Welcome Message', '', e.welcomeMessage, 'Welcome message for new chatters. Leave blank to not greet returning chatters. Tags: (names), (1 text for one name), (2 for two), (3 for three or more names)'))
                        // Add the input for first time welcome message.
                        .append(helpers.getInputGroup('welcome-message-first', 'text', 'First Chatter Welcome Message', '', e.welcomeMessageFirst, 'Welcome message for first time chatters. Leave blank to use the default welcome message. Tags: (names), (1 text for one name), (2 for two), (3 for three or more names)'))
                        // Add the input for the welcome cooldown.
                        .append(helpers.getInputGroup('welcome-cooldown', 'number', 'Welcome Cooldown (Hours)', '', (parseInt(e.cooldown) / 36e5),
                                'How many hours a user has to not chat to be welcomed again'))
                        // Add the input for excluded users.
                        .append(helpers.getFlatMultiDropdownGroup('welcome-disabled', 'Excluded Users', disabledUserOptions,
                                'Users that the bot will not welcome. Channel owner and this bot are always excluded.')),
                        function () { // Callback once the user clicks save.
                            let welcomeToggle = $('#welcome-toggle').find(':selected').text() === 'Yes',
                                    welcomeMessage = $('#welcome-message').val(),
                                    welcomeMessageFirst = $('#welcome-message-first').val(),
                                    $welcomeCooldown = $('#welcome-cooldown'),
                                    welcomeDisabled = $('#welcome-disabled').val();

                            // Make sure the user has someone in each box.
                            switch (false) {
                                case helpers.handleInputNumber($welcomeCooldown, 0):
                                    break;
                                default:
                                    socket.updateDBValues('alerts_update_welcome_settings', {
                                        tables: ['welcome', 'welcome', 'welcome', 'welcome'],
                                        keys: ['welcomeEnabled', 'welcomeMessage', 'welcomeMessageFirst', 'cooldown'],
                                        values: [welcomeToggle, welcomeMessage, welcomeMessageFirst, (parseInt($welcomeCooldown.val()) * 36e5)]
                                    }, function () {
                                        updateDisabled(disabledUsers, welcomeDisabled, function () {
                                            socket.sendCommand('alerts_update_welcome_settings_cmd', 'welcomepanelupdate', function () {
                                                // Close the modal.
                                                $('#welcome-alert').modal('toggle');
                                                // Alert the user.
                                                toastr.success('Successfully updated welcome alert settings!');
                                            });
                                        });
                                    });
                            }
                        }).modal('toggle');
                modal.find('#welcome-disabled').select2({
                    tags: true,
                    tokenSeparators: [',', ' '],
                    selectOnClose: true,
                    createTag: function (params) {
                        const term = params.term.replace(/[^a-zA-Z0-9_\n]/g, '').toLowerCase();
                        // Don't offset to create a tag if there is no @ symbol
                        if (!term) {
                            // Return null to disable tag creation
                            return null;
                        }

                        return {
                            id: term,
                            text: term
                        };
                    }
                });
            });
        });
    });

    //StreamLabs Authorization Code Flow
    $('#streamlabsLink').on('click', function () {
        let href = window.location.toString();
        if (href.includes('?')) {
            href = href.substring(0, href.indexOf('?'));
        }
        if (href.includes('#')) {
            href = href.substring(0, href.indexOf('#'));
        }
        let cp = $.currentPage();
        let authUrl = href + '?folder=' + cp.folder + '&page=' + cp.page + '&action=streamlabs-complete-auth';
        let modal = helpers.getModal('streamlabs-link', 'Link StreamLabs Account', null, $('<form/>', {
            'role': 'form'
        })
                .append($('<div/>', {
                    'class': 'box box-info'
                }).append($('<div/>', {
                    'class': 'box-header',
                    'html': 'Developer App Setup'
                })).append($('<div/>', {
                    'class': 'box-body',
                    'html': '<ol>'
                            + '<li>Login to your <a href="https://streamlabs.com/dashboard#/" target="_blank">StreamLabs Dashboard</a></li>'
                            + '<li>On the left menu, open the <b>Settings</b> page under the <i>Account</i> section</li>'
                            + '<li>Switch to the <b>Oauth Clients</b> tab'
                            + '<ul>'
                            + '<li>To use an existing v2 app:'
                            + '<ol>'
                            + '<li>Switch to the <b>My Apps</b> sub-tab</li>'
                            + '<li>Click <b>View App</b> next to the desired app</li>'
                            + '<li>Ensure the desired Twitch account is in the <i>Whitelisted Users</i> list and the <i>Redirect URL</i> is <b>' + authUrl + '</b>'
                            + '<ul><li>To update the whitelist or redirect URL:'
                            + '<ol><li>Click <b>Edit</b></li>'
                            + '<li>Click <b>Continue</b></li>'
                            + '<li>Click <b>Continue</b> again</li>'
                            + '<li>Click <b>Add</b></li>'
                            + '<li>Ensure the drop-down has <b>Twitch</b> selected</li>'
                            + '<li>Put the Username (Login Name) of the Twitch user in the <i>Username</i> text-box</li>'
                            + '<li>Update the <i>Redirect URL</i>, if neccessary</li>'
                            + '<li>Click <b>Complete</b></li>'
                            + '</ol></li></ul></li>'
                            + '</ol></li>'
                            + '<li>To create a new app or convert a v1 app:'
                            + '<ol>'
                            + '<li>Click <b>Register an App</b></li>'
                            + '<li>Select if you are creating a new app or converting an old v1 app'
                            + '<ul><li>If converting an old app, a dropdown will appear asking you to select the app</li></ul></li>'
                            + '<li>Click <b>Continue</b></li>'
                            + '<li>Fill in your personal information'
                            + '<ul><li>If not submitting this app for full approval, we have found that fake information is accepted here for privacy</li></ul></li>'
                            + '<li>Click <b>Continue</b></li>'
                            + '<li>Fill in an <b>App Name</b> that you will recognize when authorizing the bot, or reviewing your authorizations later</li>'
                            + '<li>Fill in any valid URL in the <b>Website/URL</b> box, even an unrelated one</li>'
                            + '<li>Fill in the other textboxes with any text</li>'
                            + '<li>Click <b>Continue</b></li>'
                            + '<li>Ensure the drop-down has <b>Twitch</b> selected</li>'
                            + '<li>Put the Username (Login Name) of the Twitch user in the <i>Username</i> textbox</li>'
                            + '<li>Set the <i>Redirect URL</i> to <b>' + authUrl + '</b></li>'
                            + '<li>Click <b>Complete</b></li>'
                            + '<li>A popup confirms that the app is created and your app is now in <i>Testing</i> mode</li>'
                            + '</ol></li>'
                            + '</ul>'
                            + '</li>'
                            + '<li>Copy/Paste the <b>Client ID</b> here <input type="text" id="streamlabs-link-clientid" class="form-control" autocomplete="off" /></li>'
                            + '<li>Click the <b>Client Secret</b> textbox on StreamLabs (<i>Click to reveal your client secret</i>)</li>'
                            + '<li>Copy/Paste the <b>Client Secret</b> here <input type="text" id="streamlabs-link-clientsecret" class="form-control" autocomplete="off" /></li>'
                            + '</ol>'
                }))).append($('<div/>', {
            'class': 'box box-warning'
        }).append($('<div/>', {
            'class': 'box-header',
            'html': 'Warning'
        })).append($('<div/>', {
            'class': 'box-body',
            'html': 'Failure to set the <i>Callback URI / Redirect URL</i> exactly as instructed may result in an authorization failure'
        }))).append($('<div/>', {
            'class': 'box box-info'
        }).append($('<div/>', {
            'class': 'box-header',
            'html': 'App Authorization'
        })).append($('<div/>', {
            'class': 'box-body',
            'html': '<ol id="streamlabs-link-auth">'
                    + '<li><button class="btn btn-info btn-sm" type="button" id="streamlabs-link-start-auth-button"><i class="fa fa-refresh"></i>&nbsp; Generate Auth Link</button></li>'
                    + '</ol>'
        }))), null, {'cancelclass': 'btn-primary', 'canceltext': 'Cancel'});
        modal.on('shown.bs.modal', function () {
            $('#streamlabs-link-start-auth-button').prop('disabled', true);
            $('#streamlabs-link-clientid').on('input', function() {
                $('#streamlabs-link-start-auth-button').prop('disabled', $('#streamlabs-link-clientid').val().trim().length === 0 || $('#streamlabs-link-clientsecret').val().trim().length === 0);
            });
            $('#streamlabs-link-clientsecret').on('input', function() {
                $('#streamlabs-link-start-auth-button').prop('disabled', $('#streamlabs-link-clientid').val().trim().length === 0 || $('#streamlabs-link-clientsecret').val().trim().length === 0);
            });
            $('#streamlabs-link-start-auth-button').on('click', function () {
                let clientId = $('#streamlabs-link-clientid').val().trim();
                let clientSecret = $('#streamlabs-link-clientsecret').val().trim();
                sessionStorage.setItem('streamlabs_link_clientId', clientId);
                sessionStorage.setItem('streamlabs_link_clientSecret', clientSecret);
                sessionStorage.setItem('streamlabs_link_authUrl', authUrl);
                let slauthUrl = 'https://streamlabs.com/api/v2.0/authorize?client_id=' + clientId + '&scope=donations.read&response_type=code&redirect_uri=' + encodeURIComponent(authUrl);
                $('#streamlabs-link-auth').append($('<li/>', {
                    'html': '<button class="btn btn-info btn-sm" type="button" id="streamlabs-link-do-auth-button">Connect with StreamLabs</button>',
                }));
                $('#streamlabs-link-do-auth-button').on('click', function () {
                    window.open(slauthUrl, '_blank');
                });
            });
        });

        modal.modal('toggle');
    });

    if (helpers.querymap.hasOwnProperty('action') && helpers.querymap.action === 'streamlabs-complete-auth' && helpers.querymap.hasOwnProperty('code')) {
        window.history.replaceState(null, '', window.location.origin + window.location.pathname);
        let clientId = sessionStorage.getItem('streamlabs_link_clientId');
        sessionStorage.removeItem('streamlabs_link_clientId');
        let clientSecret = sessionStorage.getItem('streamlabs_link_clientSecret');
        sessionStorage.removeItem('streamlabs_link_clientSecret');
        let authUrl = sessionStorage.getItem('streamlabs_link_authUrl');
        sessionStorage.removeItem('streamlabs_link_authUrl');
        socket.wsEvent('streamlabs_authorize', 'DonationsCache.java', null, [clientId, clientSecret, authUrl, helpers.querymap.code], function (e) {
            if (e.success) {
                swal({
                    'text': 'Successfully linked StreamLabs!',
                    'icon': 'success'
                });
            } else {
                swal({
                    'text': 'Failed to link StreamLabs!',
                    'icon': 'error'
                });
            }
        }, true);
    }

    // StreamLabs settings.
    $('#donationHandlerSettings').on('click', function () {
        socket.getDBValues('alerts_get_streamlabs_settings', {
            tables: ['donations', 'donations', 'donations'],
            keys: ['announce', 'reward', 'message']
        }, true, function (e) {
            helpers.getModal('streamlabs-alert', 'StreamLabs Alert Settings', 'Save', $('<form/>', {
                'role': 'form'
            })
                    /// Add the toggle for streamlabs alerts.
                    .append(helpers.getDropdownGroup('streamlabs-toggle', 'Enable StreamLabs Alerts', (helpers.isTrue(e.announce) ? 'Yes' : 'No'), ['Yes', 'No'],
                            'If StreamLabs tips should be posted in the chat.'))
                    // Add the the text area for the tip message.
                    .append(helpers.getTextAreaGroup('streamlabs-message', 'text', 'Tip Message', '', e.message,
                            'Message posted in the channel when someone tips with StreamLabs. Tags: (name), (amount), (amount.toFixed(0)), (points), (pointname), (currency), and (message)'))
                    // Add the the box for the tip reward
                    .append(helpers.getInputGroup('streamlabs-reward', 'number', 'Tip Reward Multiplier', '', e.reward, 'Reward multiplier for the reward.')),
                    function () { // Callback once the user clicks save.
                        let tipToggle = $('#streamlabs-toggle').find(':selected').text() === 'Yes',
                                tipMessage = $('#streamlabs-message'),
                                tipReward = $('#streamlabs-reward');

                        // Make sure the user has someone in each box.
                        switch (false) {
                            case helpers.handleInputString(tipMessage):
                            case helpers.handleInputNumber(tipReward, 0):
                                break;
                            default:
                                socket.updateDBValues('alerts_update_streamlabs_settings', {
                                    tables: ['donations', 'donations', 'donations'],
                                    keys: ['announce', 'reward', 'message'],
                                    values: [tipToggle, tipReward.val(), tipMessage.val()]
                                }, function () {
                                    socket.sendCommand('alerts_update_streamlabs_settings_cmd', 'donationpanelupdate', function () {
                                        // Close the modal.
                                        $('#streamlabs-alert').modal('toggle');
                                        // Alert the user.
                                        toastr.success('Successfully updated StreamLabs alert settings!');
                                    });
                                });
                        }
                    }).modal('toggle');
        });
    });

    // TipeeeStream settings.
    $('#tipeeeStreamHandlerSettings').on('click', function () {
        socket.getDBValues('alerts_get_tipeeestream_settings', {
            tables: ['tipeeeStreamHandler', 'tipeeeStreamHandler', 'tipeeeStreamHandler'],
            keys: ['toggle', 'reward', 'message']
        }, true, function (e) {
            helpers.getModal('tipeeestream-alert', 'TipeeeStream Alert Settings', 'Save', $('<form/>', {
                'role': 'form'
            })
                    /// Add the toggle for streamlabs alerts.
                    .append(helpers.getDropdownGroup('tipeeestream-toggle', 'Enable TipeeeStream Alerts', (helpers.isTrue(e.toggle) ? 'Yes' : 'No'), ['Yes', 'No'],
                            'If TipeeeStream tips should be posted in the chat.'))
                    // Add the the text area for the tip message.
                    .append(helpers.getTextAreaGroup('tipeeestream-message', 'text', 'Tip Message', '', e.message,
                            'Message posted in the channel when someone tips with TipeeeStream. Tags: (name), (amount), (reward), (formattedamount), and (message)'))
                    // Add the the box for the tip reward
                    .append(helpers.getInputGroup('tipeeestream-reward', 'number', 'Tip Reward Multiplier', '', e.reward, 'Reward multiplier for the reward.')),
                    function () { // Callback once the user clicks save.
                        let tipToggle = $('#tipeeestream-toggle').find(':selected').text() === 'Yes',
                                tipMessage = $('#tipeeestream-message'),
                                tipReward = $('#tipeeestream-reward');

                        // Make sure the user has someone in each box.
                        switch (false) {
                            case helpers.handleInputString(tipMessage):
                            case helpers.handleInputNumber(tipReward, 0):
                                break;
                            default:
                                socket.updateDBValues('alerts_update_tipeeestream_settings', {
                                    tables: ['tipeeeStreamHandler', 'tipeeeStreamHandler', 'tipeeeStreamHandler'],
                                    keys: ['toggle', 'reward', 'message'],
                                    values: [tipToggle, tipReward.val(), tipMessage.val()]
                                }, function () {
                                    socket.sendCommand('alerts_update_tipeeestream_settings_cmd', 'tipeeestreamreload', function () {
                                        // Close the modal.
                                        $('#tipeeestream-alert').modal('toggle');
                                        // Alert the user.
                                        toastr.success('Successfully updated TipeeeStream alert settings!');
                                    });
                                });
                        }
                    }).modal('toggle');
        });
    });

    // StreamElements settings.
    $('#streamElementsHandlerSettings').on('click', function () {
        socket.getDBValues('alerts_get_streamelements_settings', {
            tables: ['streamElementsHandler', 'streamElementsHandler', 'streamElementsHandler'],
            keys: ['toggle', 'reward', 'message']
        }, true, function (e) {
            helpers.getModal('streamelements-alert', 'StreamElements Alert Settings', 'Save', $('<form/>', {
                'role': 'form'
            })
                    /// Add the toggle for streamelements alerts.
                    .append(helpers.getDropdownGroup('streamelements-toggle', 'Enable StreamElements Alerts', (helpers.isTrue(e.toggle) ? 'Yes' : 'No'), ['Yes', 'No'],
                            'If StreamElements tips should be posted in the chat.'))
                    // Add the the text area for the tip message.
                    .append(helpers.getTextAreaGroup('streamelements-message', 'text', 'Tip Message', '', e.message,
                            'Message posted in the channel when someone tips with StreamElements. Tags: (name), (amount), (reward), (currency), and (message)'))
                    // Add the the box for the tip reward
                    .append(helpers.getInputGroup('streamelements-reward', 'number', 'Tip Reward Multiplier', '', e.reward, 'Reward multiplier for the reward.')),
                    function () { // Callback once the user clicks save.
                        let tipToggle = $('#streamelements-toggle').find(':selected').text() === 'Yes',
                                tipMessage = $('#streamelements-message'),
                                tipReward = $('#streamelements-reward');

                        // Make sure the user has someone in each box.
                        switch (false) {
                            case helpers.handleInputString(tipMessage):
                            case helpers.handleInputNumber(tipReward, 0):
                                break;
                            default:
                                socket.updateDBValues('alerts_update_streamelements_settings', {
                                    tables: ['streamElementsHandler', 'streamElementsHandler', 'streamElementsHandler'],
                                    keys: ['toggle', 'reward', 'message'],
                                    values: [tipToggle, tipReward.val(), tipMessage.val()]
                                }, function () {
                                    socket.sendCommand('alerts_update_streamelements_settings_cmd', 'streamelementsreload', function () {
                                        // Close the modal.
                                        $('#streamelements-alert').modal('toggle');
                                        // Alert the user.
                                        toastr.success('Successfully updated StreamElements alert settings!');
                                    });
                                });
                        }
                    }).modal('toggle');
        });
    });

    /**
     * Builds the settings card for a social media platform, opened with the shared settings modal
     * (customPanelSettingsModal.js). The settings are read by ./core/social.js each time they are used.
     *
     * @param {string} id the platform id, which is also its table
     * @param {string} name the platform name
     * @param {Array} pollTypes [{id, label, min}] for each kind of activity the platform can announce
     * @returns {object} the card
     */
    function socialSettingsCard(id, name, pollTypes) {
        let chatFields = [];

        pollTypes.forEach(function (type) {
            chatFields.push({id: 'poll-' + type.id, type: 'boolean', table: id, key: 'poll_' + type.id, label: 'Announce ' + type.label,
                options: ['Yes', 'No'], help: 'If ' + type.label.toLowerCase() + ' on ' + name + ' should be announced in the chat.'});
            chatFields.push({id: 'polldelay-' + type.id, type: 'number', table: id, key: 'polldelay_' + type.id, label: type.label + ' Check Interval (Seconds)',
                min: type.min, help: 'How often to check ' + name + ' for these, in seconds. Minimum is ' + type.min + ' seconds.'});
        });

        return {
            id: id,
            section: 'alerts',
            title: name + ' Alerts',
            settingsModal: {
                title: name + ' Alert Settings',
                sections: [{
                    id: 'chat',
                    title: 'Chat Announcements',
                    fields: chatFields
                }, {
                    id: 'reward',
                    title: 'Repost Rewards',
                    fields: [
                        {id: 'reward-toggle', type: 'boolean', table: id, key: 'reward_toggle', label: 'Reward Reposts', options: ['Yes', 'No'],
                            help: 'If viewers who registered their ' + name + ' account with !' + id + ' register should get points for reposting your posts.'},
                        {id: 'reward-announce', type: 'boolean', table: id, key: 'reward_announce', label: 'Announce Rewards', options: ['Yes', 'No'],
                            help: 'If rewards should be announced in the chat.'},
                        {id: 'reward-points', type: 'number', table: id, key: 'reward_points', label: 'Reward Points', min: 0,
                            help: 'Points given for a repost. Set to 0 to give none.'},
                        {id: 'reward-cooldown', type: 'number', table: id, key: 'reward_cooldown', label: 'Reward Cooldown (Hours)', min: 0,
                            help: 'Hours a viewer must wait between rewards.'}
                    ]
                }, {
                    id: 'post',
                    title: 'Automatic Posts',
                    fields: [
                        {id: 'post-online', type: 'boolean', table: id, key: 'post_online', label: 'Post When Going Live', options: ['Yes', 'No'],
                            help: 'If the bot should post to ' + name + ' when the stream goes live, at most once every 8 hours.'},
                        {id: 'message-online', type: 'textarea', table: id, key: 'message_online', label: 'Going Live Post',
                            help: 'Tags: (title), (game), (uptime), (twitchurl) and (enter) for a line break. A link card for the stream is added.'},
                        {id: 'post-gamechange', type: 'boolean', table: id, key: 'post_gamechange', label: 'Post When Changing Game', options: ['Yes', 'No'],
                            help: 'If the bot should post to ' + name + ' when the game changes while live, at most once an hour.'},
                        {id: 'message-gamechange', type: 'textarea', table: id, key: 'message_gamechange', label: 'Game Change Post',
                            help: 'Tags: (title), (game), (uptime), (twitchurl) and (enter) for a line break.'},
                        {id: 'post-update', type: 'boolean', table: id, key: 'post_update', label: 'Post Updates While Live', options: ['Yes', 'No'],
                            help: 'If the bot should post to ' + name + ' periodically while live.'},
                        {id: 'message-update', type: 'textarea', table: id, key: 'message_update', label: 'Update Post',
                            help: 'Tags: (title), (game), (uptime), (twitchurl) and (enter) for a line break.'},
                        {id: 'postdelay-update', type: 'number', table: id, key: 'postdelay_update', label: 'Update Interval (Minutes)', min: 180,
                            help: 'Minutes between update posts. Minimum is 180 minutes.'}
                    ]
                }]
            }
        };
    }

    // Bluesky settings.
    $('#blueskyHandlerSettings').on('click', function () {
        window.__pbCustomPanel__.openSettingsModal(socialSettingsCard('bluesky', 'Bluesky', [
            {id: 'mentions', label: 'Mentions, Replies and Quotes', min: 60},
            {id: 'reposts', label: 'Reposts', min: 60},
            {id: 'posts', label: 'Your Posts', min: 15}
        ]));
    });

    // Bluesky account link. Only shown to the bot's config users.
    $('#blueskyLink').on('click', helpers.openBlueskyLinkModal);
});
