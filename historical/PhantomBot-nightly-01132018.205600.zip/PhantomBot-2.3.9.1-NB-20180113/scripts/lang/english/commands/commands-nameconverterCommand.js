$.lang.register('namechange.default', 'Usage: !namechange [old name] [new name]');
$.lang.register('namechange.updating', 'Updating name $1 to $2 in all the database tables. This may take time.');
$.lang.register('namechange.success', 'Username $1 has been updated to $2 in $3 tables!');
$.lang.register('namechange.notfound', 'Username $1 was not found in any tables.');
