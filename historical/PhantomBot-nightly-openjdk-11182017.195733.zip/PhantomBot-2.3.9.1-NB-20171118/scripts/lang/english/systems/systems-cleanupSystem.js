$.lang.register('cleanupsystem.run.progress', 'Cleanup is starting, $1 might be unresponsive or slow during this process. This might take time...');
$.lang.register('cleanupsystem.run.success', 'Cleanup done!');
$.lang.register('cleanupsystem.run.usage', 'Usage: !cleanup [time / points / all] [amount of time in seconds or points if cleaning points]');