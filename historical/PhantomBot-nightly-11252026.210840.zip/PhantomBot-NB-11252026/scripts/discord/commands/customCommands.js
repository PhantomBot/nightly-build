/*
 * Copyright (C) 2016-2026 phantombot.github.io/PhantomBot
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * This module is to handle custom commands for discord.
 */
(function () {

    /**
     * @function permCom
     *
     * @export $.discord
     * @param {string} command
     * @param {string} subCommand
     * @return {int}
     */
    function permCom(command, subCommand) {
        if (subCommand === '') {
            return $.discord.getCommandPermission(command);
        } else {
            return $.discord.getSubCommandPermission(command, subCommand);
        }
    }

    /**
     * @function loadCustomCommands
     *
     * @export $.discord
     */
    function loadCustomCommands() {
        if ($.bot.isModuleEnabled('./discord/commands/customCommands.js')) {
            var keys = $.inidb.GetKeyList('discordCommands', ''),
                    i;

            for (i = 0; i < keys.length; i++) {
                $.discord.registerCommand('./discord/commands/customCommands.js', keys[i], 0);
            }
        }
    }

    /*
     * @event discordChannelCommand
     * @usestransformers global discord commandevent noevent
     */
    $.bind('discordChannelCommand', function (event) {
        var channel = event.getDiscordChannel(),
                command = event.getCommand(),
                mention = event.getMention(),
                args = event.getArgs(),
                action = args[0],
                subAction = args[1];

        /**
         * Checks for custom commands, no command path needed here.
         */
        let discordCommand = $.optIniDbString('discordCommands', command);
        if (discordCommand.isPresent()) {
            var tag = $.transformers.tags(event, discordCommand.get(), ['discord', ['commandevent', 'noevent']], {platform: 'discord'});
            if (tag !== null) {
                $.discord.say(channel, tag);
            }
            return;
        }

        /**
         * @discordcommandpath addcom [command] [response] - Adds a custom command to be used in your Discord server.
         */
        if ($.equalsIgnoreCase(command, 'addcom')) {
            if (action === undefined || subAction === undefined) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.addcom.usage'));
                return;
            }

            action = action.replace('!', '').toLowerCase();

            if ($.discord.commandExists(action)) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.addcom.err'));
                return;
            }

            $.inidb.set('discordCommands', action, args.slice(1).join(' '));
            $.discord.registerCommand('./discord/commands/customCommands.js', action, 0);
            $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.addcom.success', action));
        }

        /**
         * @discordcommandpath editcom [command] [response] - Edits an existing command.
         */
        if ($.equalsIgnoreCase(command, 'editcom')) {
            if (action === undefined || subAction === undefined) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.editcom.usage'));
                return;
            }

            action = action.replace('!', '').toLowerCase();

            if (!$.discord.commandExists(action)) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.editcom.404'));
                return;
            }

            $.inidb.set('discordCommands', action, args.slice(1).join(' '));
            $.discord.registerCommand('./discord/commands/customCommands.js', action, 0);
            $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.editcom.success', action));
        }

        /**
         * @discordcommandpath delcom [command] - Deletes a custom command.
         */
        if ($.equalsIgnoreCase(command, 'delcom')) {
            if (action === undefined) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.delcom.usage'));
                return;
            }

            action = action.replace('!', '').toLowerCase();

            if (!$.discord.commandExists(action)) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.delcom.404'));
                return;
            }

            $.inidb.del('discordCommands', action);
            $.inidb.del('discordApiCommandSecrets', action);
            $.discord.unregisterCommand(action);
            $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.delcom.success', action));
        }

        /**
         * @discordcommandpath secretcom [command] (secret) (header) - Ties a saved API secret to the command, so each (api) request of the command sends it in the header, Authorization as Bearer if left out. Without a secret, shows which one is tied
         */
        if ($.equalsIgnoreCase(command, 'secretcom')) {
            if (action === undefined) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.secret.usage'));
                return;
            }

            action = $.jsString(action).replace('!', '').toLowerCase();

            if (!$.inidb.exists('discordCommands', action)) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.404'));
                return;
            }

            if (subAction === undefined) {
                let tie = $.optIniDbString('discordApiCommandSecrets', action);
                if (tie.isPresent()) {
                    tie = JSON.parse(tie.get());
                    $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.secret.show', action, tie.secret, tie.header));
                } else {
                    $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.secret.none', action));
                }
                return;
            }

            let secret = $.jsString(subAction).toLowerCase(),
                    header = args[2] === undefined ? 'Authorization' : $.jsString(args[2]);

            // Only secrets saved in the panel can be tied
            if (!$.inidb.exists('apiSecrets', secret)) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.secret.404'));
                return;
            }

            if (!/^[\w-]+$/.test(header)) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.secret.header'));
                return;
            }

            $.inidb.set('discordApiCommandSecrets', action, JSON.stringify({secret: secret, header: header}));
            $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.secret.success', secret, action, header));
            return;
        }

        /**
         * @discordcommandpath delsecretcom [command] - Stops sending the API secret tied to the command
         */
        if ($.equalsIgnoreCase(command, 'delsecretcom')) {
            if (action === undefined) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.delsecret.usage'));
                return;
            }

            action = $.jsString(action).replace('!', '').toLowerCase();

            if (!$.inidb.exists('discordCommands', action)) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.404'));
                return;
            } else if (!$.inidb.exists('discordApiCommandSecrets', action)) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.secret.none', action));
                return;
            }

            $.inidb.del('discordApiCommandSecrets', action);
            $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.delsecret.success', action));
            return;
        }

        /**
         * @discordcommandpath channelcom [command] [channel / --global / --list] - Makes a command only work in that channel, separate the channels with commas (no spaces) for multiple, use --global as the channel to make the command global again.
         */
        if ($.equalsIgnoreCase(command, 'channelcom')) {
            if (action === undefined || subAction === undefined) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.channelcom.usage'));
                return;
            }

            action = action.replace('!', '').toLowerCase();

            if (!$.discord.commandExists(action)) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.404'));
                return;
            }

            if ($.equalsIgnoreCase(subAction, '--global') || $.equalsIgnoreCase(subAction, '-g')) {
                $.inidb.del('discordChannelcom', action);
                $.discord.updateCommandChannel(action);
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.channelcom.global', action));
                return;
            } else if ($.equalsIgnoreCase(subAction, '--list') || $.equalsIgnoreCase(subAction, '-l')) {
                let keys = $.inidb.OptString('discordChannelcom', '',action),
                        key = [],
                        i;

                keys = keys.isPresent() ? keys.get().split(',') : []
                for (i in keys) {
                    key.push('#' + keys[i]);
                }

                if (key.length !== 0) {
                    $.discord.say(channel, $.discord.userPrefix(mention) + key.join(', '));
                } else {
                    $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.channelcom.404'));
                }
                return;
            }

            var keys = subAction.split(','),
                    key = [],
                    i;

            for (i in keys) {
                key.push($.discord.sanitizeChannelName(keys[i]));
            }

            $.inidb.set('discordChannelcom', action, key.join(','));
            $.discord.updateCommandChannel(action);
            $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.channelcom.success', action, subAction.replace(',', ', ')));
        }

        /**
         * @discordcommandpath pricecom [command] [amount] - Sets a cost for that command, users must of their Twitch accounts linked for this to work.
         */
        if ($.equalsIgnoreCase(command, 'pricecom')) {
            if (action === undefined || (subAction === undefined || isNaN(parseInt(subAction)))) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.pricecom.usage'));
                return;
            }

            action = action.replace('!', '').toLowerCase();

            if (!$.discord.commandExists(action)) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.404'));
                return;
            }

            $.inidb.set('discordPricecom', action, subAction);
            $.discord.setCommandCost(action, subAction);
            $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.pricecom.success', action, $.getPointsString(subAction)));
        }

        /**
         * @discordcommandpath aliascom [alias] [command] - Alias a command to another command, this only works with commands that have a single command.
         */
        if ($.equalsIgnoreCase(command, 'aliascom')) {
            if (action === undefined || subAction === undefined) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.aliascom.usage'));
                return;
            }

            action = action.replace('!', '').toLowerCase();
            subAction = subAction.replace('!', '').toLowerCase();

            if (!$.discord.commandExists(subAction)) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.404'));
                return;
            }

            $.inidb.set('discordAliascom', subAction, action);
            $.discord.setCommandAlias(subAction, action);
            $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.aliascom.success', action, subAction));
        }

        /**
         * @discordcommandpath delalias [alias] - Removes the alias of that command.
         */
        if ($.equalsIgnoreCase(command, 'delalias')) {
            if (action === undefined) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.delalias.usage'));
                return;
            }

            action = action.replace('!', '').toLowerCase();

            if (!$.discord.aliasExists(action)) {
                $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.alias.404'));
                return;
            }

            var keys = $.inidb.GetKeyList('discordAliascom', ''),
                    i;
            for (i in keys) {
                if ($.equalsIgnoreCase($.getIniDbString('discordAliascom', keys[i]), action)) {
                    $.inidb.del('discordAliascom', keys[i]);
                    $.discord.removeAlias(keys[i], '');
                }
            }
            $.discord.say(channel, $.discord.userPrefix(mention) + $.lang.get('discord.customcommands.delalias.success', action));
        }

        /**
         * @discordcommandpath commands - Shows all of the custom commands you created.
         */
        if ($.equalsIgnoreCase(command, 'commands')) {
            var keys = $.inidb.GetKeyList('discordCommands', ''),
                    temp = [],
                    i;

            for (i = 0; i < keys.length; i++) {
                temp.push('!' + keys[i]);
            }

            $.paginateArrayDiscord(temp, 'discord.customcommands.commands', ', ', channel, mention);
        }

        /**
         * @discordcommandpath botcommands - Gives you a list of commands that you are allowed to use.
         */
        if ($.equalsIgnoreCase(command, 'botcommands')) {
            var keys = $.inidb.GetKeyList('discordPermcom', ''),
                    temp = [],
                    i;

            for (i = 0; i < keys.length; i++) {
                if (keys[i].indexOf(' ') === -1) {
                    temp.push('!' + keys[i]);
                }
            }
            $.paginateArrayDiscord(temp, 'discord.customcommands.bot.commands', ', ', channel, mention);
        }
    });

    /**
     * @event discordReady
     */
    $.bind('discordReady', function () {
        $.discord.registerCommand('./discord/commands/customCommands.js', 'addcom', 1);
        $.discord.registerCommand('./discord/commands/customCommands.js', 'delcom', 1);
        $.discord.registerCommand('./discord/commands/customCommands.js', 'editcom', 1);
        $.discord.registerCommand('./discord/commands/customCommands.js', 'coolcom', 1);
        $.discord.registerCommand('./discord/commands/customCommands.js', 'channelcom', 1);
        $.discord.registerCommand('./discord/commands/customCommands.js', 'pricecom', 1);
        $.discord.registerCommand('./discord/commands/customCommands.js', 'aliascom', 1);
        $.discord.registerCommand('./discord/commands/customCommands.js', 'delalias', 1);
        $.discord.registerCommand('./discord/commands/customCommands.js', 'secretcom', 1);
        $.discord.registerCommand('./discord/commands/customCommands.js', 'delsecretcom', 1);
        $.discord.registerCommand('./discord/commands/customCommands.js', 'commands', 0);
        $.discord.registerCommand('./discord/commands/customCommands.js', 'botcommands', 1);

        loadCustomCommands();
    });

    /**
     * @event webPanelSocketUpdate
     */
    $.bind('webPanelSocketUpdate', function (event) {
        if ($.equalsIgnoreCase(event.getScript(), './discord/commands/customCommands.js')) {
            if ($.strlen(event.getArguments()) === 0) {
                if (!$.discord.commandExists(event.getArgs()[0])) {
                    $.discord.registerCommand('./discord/commands/customCommands.js', event.getArgs()[0], event.getArgs()[1]);
                } else {
                    $.discord.setCommandPermission(event.getArgs()[0], event.getArgs()[1]);
                    $.discord.setCommandCost(event.getArgs()[0], ($.strlen(event.getArgs()[4]) === 0 ? '' : event.getArgs()[4]));
                    if ($.strlen(event.getArgs()[3]) === 0) {
                        $.discord.removeAlias(event.getArgs()[0], $.getIniDbString('discordAliascom', event.getArgs()[0]));
                    } else {
                        $.discord.setCommandAlias(event.getArgs()[0], ($.strlen(event.getArgs()[3]) === 0 ? '' : event.getArgs()[3]));
                    }

                    if ($.strlen(event.getArgs()[2]) === 0) {
                        $.inidb.del('discordChannelcom', event.getArgs()[0]);
                    } else {
                        $.inidb.set('discordChannelcom', event.getArgs()[0], String(event.getArgs()[2]).replace(/#/g, '').toLowerCase());
                    }

                    $.discord.updateCommandChannel(event.getArgs()[0]);
                }
            } else {
                $.discord.unregisterCommand(event.getArgs()[0]);
            }
        }
    });

    /* Export the function to the $.discord api. */
    $.discord.loadCustomCommands = loadCustomCommands;
    $.discord.permCom = permCom;
})();
